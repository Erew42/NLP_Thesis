from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
import warnings

import polars as pl
import pytest

from thesis_pkg.core.ccm.sec_ccm_contracts import (
    MatchReasonCode,
    PhaseBAlignmentMode,
    PhaseBDailyJoinMode,
    SEC_CCM_PHASE_B_DAILY_FEATURE_COLUMNS,
    SecCcmJoinSpecV1,
    SecCcmJoinSpecV2,
    make_sec_ccm_join_spec_preset,
    normalize_sec_ccm_join_spec,
)
from thesis_pkg.core.ccm.sec_ccm_premerge import (
    align_doc_dates_phase_b,
    apply_phase_b_reason_codes,
    build_match_status_doc,
    build_unmatched_diagnostics_doc,
    normalize_sec_filings_phase_a,
    resolve_links_phase_a,
    join_daily_phase_b,
)
from thesis_pkg.core.ccm.transforms import (
    DataStatus,
    STATUS_DTYPE,
    apply_concept_filter_flags_doc,
    project_ccm_daily_phase_b_surface,
)
from thesis_pkg.pipelines.sec_ccm_pipeline import run_sec_ccm_premerge_pipeline


def _canonical_links(rows: list[dict[str, object]]) -> pl.DataFrame:
    base = {
        "cik_10": "0000000000",
        "gvkey": "0",
        "kypermno": 0,
        "lpermco": None,
        "liid": "01",
        "valid_start": dt.date(1900, 1, 1),
        "valid_end": None,
        "link_start": dt.date(1900, 1, 1),
        "link_end": None,
        "cik_start": None,
        "cik_end": None,
        "linktype": "LC",
        "linkprim": "P",
        "link_rank_raw": None,
        "link_rank_effective": 90,
        "link_quality": 4.0,
        "link_source": "linkhistory",
        "source_priority": 1,
        "row_quality_tier": 10,
        "has_window": True,
        "is_sparse_fallback": False,
    }
    return pl.DataFrame([{**base, **row} for row in rows])


def test_join_spec_normalization_from_v1_and_presets():
    v1 = SecCcmJoinSpecV1(
        daily_join_source="MERGED_DAILY_PANEL",
        required_daily_non_null_features=("RET",),
    )
    v2 = normalize_sec_ccm_join_spec(v1)
    assert v2.version == "v2"
    assert v2.phase_b_alignment_mode == PhaseBAlignmentMode.NEXT_TRADING_DAY_STRICT
    assert v2.phase_b_daily_join_mode == PhaseBDailyJoinMode.ASOF_FORWARD
    assert v2.daily_join_source == "MERGED_DAILY_PANEL"
    assert v2.required_daily_non_null_features == ("RET",)
    assert v2.daily_join_max_forward_lag_days == 14
    assert "TICKER" in SecCcmJoinSpecV1().daily_feature_columns
    assert "FINAL_PRC" in SecCcmJoinSpecV1().daily_feature_columns
    assert "SHROUT" in SecCcmJoinSpecV1().daily_feature_columns
    assert "TICKER" in v2.daily_feature_columns
    assert "FINAL_PRC" in v2.daily_feature_columns
    assert "SHROUT" in v2.daily_feature_columns

    lm2011 = make_sec_ccm_join_spec_preset("lm2011_filing_date")
    assert lm2011.phase_b_alignment_mode == PhaseBAlignmentMode.FILING_DATE_EXACT_OR_NEXT_TRADING
    assert lm2011.phase_b_daily_join_mode == PhaseBDailyJoinMode.EXACT_ON_ALIGNED_DATE

    strict = make_sec_ccm_join_spec_preset("strict_exact_diagnostic")
    assert strict.phase_b_alignment_mode == PhaseBAlignmentMode.FILING_DATE_EXACT_ONLY
    assert strict.phase_b_daily_join_mode == PhaseBDailyJoinMode.EXACT_ON_ALIGNED_DATE


def test_first_close_after_acceptance_v1_is_rejected():
    with pytest.raises(ValueError, match="FIRST_CLOSE_AFTER_ACCEPTANCE"):
        normalize_sec_ccm_join_spec(
            SecCcmJoinSpecV1(alignment_policy="FIRST_CLOSE_AFTER_ACCEPTANCE")
        )


def test_phase_a_reason_codes_and_doc_grain_invariants():
    sec = pl.DataFrame(
        {
            "doc_id": ["d1", "d2", "d3", "d4", "d5", "d6", "d7"],
            "cik_10": ["0000000001", "bad_cik", "0000000003", "0000000004", "0000000005", "0000000006", "0000000007"],
            "filing_date": [dt.date(2024, 1, 2)] * 7,
            "acceptance_datetime": [dt.datetime(2024, 1, 2, 16, 0), None, None, None, None, None, None],
        }
    )

    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1, "link_quality": 3.0},
            {"cik_10": "0000000004", "gvkey": "4000", "kypermno": 4, "link_quality": 2.0},
            {"cik_10": "0000000004", "gvkey": "4001", "kypermno": 5, "link_quality": 2.0},
            {"cik_10": "0000000005", "gvkey": "5000", "kypermno": 0, "link_quality": 1.0},
            {
                "cik_10": "0000000006",
                "gvkey": "6000",
                "kypermno": 6,
                "link_quality": 3.0,
                "valid_start": dt.date(2024, 2, 1),
            },
            {
                "cik_10": "0000000007",
                "gvkey": "7000",
                "kypermno": 7,
                "link_quality": 3.0,
                "has_window": False,
                "is_sparse_fallback": False,
            },
        ]
    )

    phase_a = resolve_links_phase_a(sec.lazy(), link_universe.lazy()).collect().sort("doc_id")
    by_doc = {row["doc_id"]: row for row in phase_a.to_dicts()}
    reasons = {doc_id: row["phase_a_reason_code"] for doc_id, row in by_doc.items()}

    assert phase_a.height == sec.height
    assert phase_a["doc_id"].n_unique() == sec.height
    assert reasons["d1"] == MatchReasonCode.OK.value
    assert reasons["d2"] == MatchReasonCode.BAD_INPUT.value
    assert reasons["d3"] == MatchReasonCode.CIK_NOT_IN_LINK_UNIVERSE.value
    assert reasons["d4"] == MatchReasonCode.AMBIGUOUS_LINK.value
    assert reasons["d5"] == MatchReasonCode.CIK_PRESENT_NO_POSITIVE_LINK.value
    assert reasons["d6"] == MatchReasonCode.NO_DATE_VALID_POSITIVE_LINK.value
    assert reasons["d7"] == MatchReasonCode.NO_ELIGIBLE_LINK_CANDIDATE.value
    assert by_doc["d4"]["kypermno"] is None
    assert by_doc["d5"]["data_status"] & int(DataStatus.SEC_CCM_CIK_PRESENT_NO_POSITIVE_LINK)
    assert by_doc["d6"]["data_status"] & int(DataStatus.SEC_CCM_NO_DATE_VALID_POSITIVE_LINK)
    assert by_doc["d7"]["data_status"] & int(DataStatus.SEC_CCM_NO_ELIGIBLE_LINK_CANDIDATE)
    assert phase_a.schema["kypermno"] == pl.Int32
    assert phase_a.schema["data_status"] == STATUS_DTYPE
    assert phase_a.select(pl.col("data_status").is_null().any()).item() is False


def test_phase_b_strict_next_day_alignment_and_reason_scoping():
    sec = pl.DataFrame(
        {
            "doc_id": ["ok", "out_cov", "ambig", "no_row"],
            "cik_10": ["0000000001", "0000000002", "0000000003", "0000000004"],
            "filing_date": [
                dt.date(2024, 1, 2),
                dt.date(2024, 1, 4),
                dt.date(2024, 1, 2),
                dt.date(2024, 1, 2),
            ],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1, "link_quality": 4.0},
            {"cik_10": "0000000002", "gvkey": "2000", "kypermno": 2, "link_quality": 4.0},
            {"cik_10": "0000000003", "gvkey": "3000", "kypermno": 3, "link_quality": 3.0},
            {"cik_10": "0000000003", "gvkey": "3001", "kypermno": 4, "link_quality": 3.0},
            {"cik_10": "0000000004", "gvkey": "4000", "kypermno": 5, "link_quality": 4.0},
        ]
    )
    trading_calendar = pl.DataFrame({"CALDT": [dt.date(2024, 1, 3), dt.date(2024, 1, 4)]})
    daily = pl.DataFrame(
        {
            "KYPERMNO": [1, 5],
            "CALDT": [dt.date(2024, 1, 3), dt.date(2024, 1, 3)],
            "RET": [0.01, None],
            "RETX": [0.01, 0.01],
            "PRC": [10.0, 12.0],
            "BIDLO": [9.5, 11.5],
            "ASKHI": [10.5, 12.5],
        }
    )

    phase_a = resolve_links_phase_a(sec.lazy(), link_universe.lazy())
    aligned = align_doc_dates_phase_b(phase_a, trading_calendar.lazy(), SecCcmJoinSpecV1())
    aligned_df = aligned.collect()

    assert (
        aligned_df.filter(pl.col("aligned_caldt").is_not_null())
        .select((pl.col("aligned_caldt") > pl.col("filing_date")).all())
        .item()
        is True
    )
    assert (
        aligned_df.filter(pl.col("aligned_caldt").is_not_null())
        .select((pl.col("alignment_lag_days") >= 1).all())
        .item()
        is True
    )

    join_spec = SecCcmJoinSpecV1(required_daily_non_null_features=("RET",))
    joined = join_daily_phase_b(aligned, daily.lazy(), join_spec)
    final = apply_phase_b_reason_codes(phase_a, joined, join_spec).collect().sort("doc_id")

    by_doc = {row["doc_id"]: row for row in final.to_dicts()}
    assert by_doc["ok"]["match_reason_code"] == MatchReasonCode.OK.value
    assert by_doc["out_cov"]["match_reason_code"] == MatchReasonCode.OUT_OF_CCM_COVERAGE.value
    assert by_doc["no_row"]["match_reason_code"] == MatchReasonCode.REQUIRED_DAILY_FEATURE_MISSING.value
    assert by_doc["no_row"]["phase_b_reason_code"] == MatchReasonCode.REQUIRED_DAILY_FEATURE_MISSING.value
    assert by_doc["no_row"]["_daily_row_failed_required_features"] is True
    assert by_doc["no_row"]["data_status"] & int(DataStatus.SEC_CCM_PHASE_B_REQUIRED_DAILY_FEATURE_MISSING)
    assert by_doc["ambig"]["phase_a_reason_code"] == MatchReasonCode.AMBIGUOUS_LINK.value
    assert by_doc["ambig"]["match_reason_code"] == MatchReasonCode.AMBIGUOUS_LINK.value
    assert by_doc["ambig"]["phase_b_reason_code"] is None


def test_grouped_asof_join_sorts_inputs_and_avoids_sortedness_warning():
    sec = pl.DataFrame(
        {
            "doc_id": ["d1", "d2"],
            "cik_10": ["0000000001", "0000000002"],
            "filing_date": [dt.date(2024, 1, 2), dt.date(2024, 1, 2)],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
            {"cik_10": "0000000002", "gvkey": "2000", "kypermno": 2},
        ]
    )
    trading_calendar = pl.DataFrame({"CALDT": [dt.date(2024, 1, 3), dt.date(2024, 1, 4)]})
    # Intentionally unsorted to verify the function's internal sort path.
    daily = pl.DataFrame(
        {
            "KYPERMNO": [2, 1],
            "CALDT": [dt.date(2024, 1, 3), dt.date(2024, 1, 3)],
            "RET": [0.02, 0.01],
        }
    )

    phase_a = resolve_links_phase_a(sec.lazy(), link_universe.lazy())
    aligned = align_doc_dates_phase_b(phase_a, trading_calendar.lazy(), SecCcmJoinSpecV1())

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        out = join_daily_phase_b(aligned, daily.lazy(), SecCcmJoinSpecV1(required_daily_non_null_features=("RET",)))
        out.collect()

    assert not any(
        "Sortedness of columns cannot be checked when 'by' groups provided" in str(w.message)
        for w in caught
    )


def test_alignment_mode_filing_date_exact_or_next_trading_supports_lag_zero_and_roll_forward():
    sec = pl.DataFrame(
        {
            "doc_id": ["trade_day", "weekend_day"],
            "cik_10": ["0000000001", "0000000002"],
            "filing_date": [dt.date(2024, 1, 2), dt.date(2024, 1, 6)],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
            {"cik_10": "0000000002", "gvkey": "2000", "kypermno": 2},
        ]
    )
    trading_calendar = pl.DataFrame(
        {"CALDT": [dt.date(2024, 1, 2), dt.date(2024, 1, 3), dt.date(2024, 1, 8)]}
    )
    phase_a = resolve_links_phase_a(sec.lazy(), link_universe.lazy())
    aligned = align_doc_dates_phase_b(
        phase_a,
        trading_calendar.lazy(),
        SecCcmJoinSpecV2(
            phase_b_alignment_mode=PhaseBAlignmentMode.FILING_DATE_EXACT_OR_NEXT_TRADING,
        ),
    ).collect()
    rows = {row["doc_id"]: row for row in aligned.to_dicts()}

    assert rows["trade_day"]["aligned_caldt"] == dt.date(2024, 1, 2)
    assert rows["trade_day"]["alignment_lag_days"] == 0
    assert rows["weekend_day"]["aligned_caldt"] == dt.date(2024, 1, 8)
    assert rows["weekend_day"]["alignment_lag_days"] == 2


def test_alignment_mode_filing_date_exact_only_leaves_non_trading_dates_unaligned():
    sec = pl.DataFrame(
        {
            "doc_id": ["weekend_day"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 6)],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
        ]
    )
    trading_calendar = pl.DataFrame({"CALDT": [dt.date(2024, 1, 5), dt.date(2024, 1, 8)]})
    phase_a = resolve_links_phase_a(sec.lazy(), link_universe.lazy())
    aligned = align_doc_dates_phase_b(
        phase_a,
        trading_calendar.lazy(),
        SecCcmJoinSpecV2(phase_b_alignment_mode=PhaseBAlignmentMode.FILING_DATE_EXACT_ONLY),
    ).collect()
    row = aligned.row(0, named=True)

    assert row["aligned_caldt"] is None
    assert row["alignment_lag_days"] is None
    assert row["data_status"] & int(DataStatus.SEC_CCM_PHASE_B_ALIGNMENT_ATTEMPTED)
    assert (row["data_status"] & int(DataStatus.SEC_CCM_PHASE_B_ALIGNED)) == 0


def test_daily_join_mode_exact_vs_forward_controls_fallback_and_lag():
    aligned = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 2)],
            "kypermno": [1],
            "phase_a_reason_code": [MatchReasonCode.OK.value],
            "data_status": [0],
            "aligned_caldt": [dt.date(2024, 1, 3)],
            "alignment_lag_days": [1],
        }
    ).lazy()
    daily = pl.DataFrame(
        {
            "KYPERMNO": [1],
            "CALDT": [dt.date(2024, 1, 4)],
            "RET": [0.01],
        }
    ).lazy()

    exact_out = join_daily_phase_b(
        aligned,
        daily,
        SecCcmJoinSpecV2(
            phase_b_daily_join_mode=PhaseBDailyJoinMode.EXACT_ON_ALIGNED_DATE,
            required_daily_non_null_features=("RET",),
        ),
    ).collect().row(0, named=True)
    assert exact_out["daily_join_caldt"] is None
    assert exact_out["daily_join_lag_days"] is None
    assert (exact_out["data_status"] & int(DataStatus.SEC_CCM_PHASE_B_DAILY_ROW_FOUND)) == 0

    forward_out = join_daily_phase_b(
        aligned,
        daily,
        SecCcmJoinSpecV2(
            phase_b_daily_join_mode=PhaseBDailyJoinMode.ASOF_FORWARD,
            required_daily_non_null_features=("RET",),
        ),
    ).collect().row(0, named=True)
    assert forward_out["daily_join_caldt"] == dt.date(2024, 1, 4)
    assert forward_out["daily_join_lag_days"] == 1
    assert forward_out["data_status"] & int(DataStatus.SEC_CCM_PHASE_B_DAILY_ROW_FOUND)


def test_required_feature_omitted_from_daily_feature_list_is_still_projected_and_enforced():
    aligned = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 2)],
            "kypermno": [1],
            "phase_a_reason_code": [MatchReasonCode.OK.value],
            "data_status": [0],
            "aligned_caldt": [dt.date(2024, 1, 3)],
            "alignment_lag_days": [1],
        }
    ).lazy()
    daily = pl.DataFrame(
        {
            "KYPERMNO": [1],
            "CALDT": [dt.date(2024, 1, 3)],
            "RET": [0.01],
        }
    ).lazy()
    out = join_daily_phase_b(
        aligned,
        daily,
        SecCcmJoinSpecV2(
            daily_feature_columns=("PRC",),
            required_daily_non_null_features=("RET",),
        ),
    ).collect().row(0, named=True)

    assert out["daily_join_caldt"] == dt.date(2024, 1, 3)
    assert out["_has_usable_daily_row"] is True
    assert out["data_status"] & int(DataStatus.SEC_CCM_PHASE_B_DAILY_ROW_FOUND)


def test_forward_asof_lag_gate_boundaries_and_reason_routing():
    aligned = pl.DataFrame(
        {
            "doc_id": ["d13", "d14", "d15"],
            "cik_10": ["0000000013", "0000000014", "0000000015"],
            "filing_date": [dt.date(2024, 1, 1), dt.date(2024, 1, 1), dt.date(2024, 1, 1)],
            "kypermno": [13, 14, 15],
            "phase_a_reason_code": [MatchReasonCode.OK.value, MatchReasonCode.OK.value, MatchReasonCode.OK.value],
            "data_status": [0, 0, 0],
            "aligned_caldt": [dt.date(2024, 1, 1), dt.date(2024, 1, 1), dt.date(2024, 1, 1)],
            "alignment_lag_days": [0, 0, 0],
        }
    ).lazy()
    daily = pl.DataFrame(
        {
            "KYPERMNO": [13, 13, 14, 14, 15, 15],
            "CALDT": [
                dt.date(2023, 12, 25),
                dt.date(2024, 1, 14),
                dt.date(2023, 12, 25),
                dt.date(2024, 1, 15),
                dt.date(2023, 12, 25),
                dt.date(2024, 1, 16),
            ],
            "RET": [0.0, 0.01, 0.0, 0.01, 0.0, 0.01],
        }
    ).lazy()
    join_spec = SecCcmJoinSpecV2(
        phase_b_daily_join_mode=PhaseBDailyJoinMode.ASOF_FORWARD,
        required_daily_non_null_features=("RET",),
        daily_join_max_forward_lag_days=14,
    )

    joined = join_daily_phase_b(aligned, daily, join_spec).collect().sort("doc_id")
    by_doc = {row["doc_id"]: row for row in joined.to_dicts()}
    assert by_doc["d13"]["daily_join_lag_days"] == 13
    assert by_doc["d14"]["daily_join_lag_days"] == 14
    assert by_doc["d15"]["daily_join_lag_days"] == 15
    assert by_doc["d13"]["daily_lag_gate_rejected"] is False
    assert by_doc["d14"]["daily_lag_gate_rejected"] is False
    assert by_doc["d15"]["daily_lag_gate_rejected"] is True
    assert by_doc["d13"]["_has_usable_daily_row"] is True
    assert by_doc["d14"]["_has_usable_daily_row"] is True
    assert by_doc["d15"]["_has_usable_daily_row"] is False

    phase_a = aligned.select("doc_id", "phase_a_reason_code")
    final = apply_phase_b_reason_codes(phase_a, joined.lazy(), join_spec).collect().sort("doc_id")
    final_by_doc = {row["doc_id"]: row for row in final.to_dicts()}
    assert final_by_doc["d13"]["match_reason_code"] == MatchReasonCode.OK.value
    assert final_by_doc["d14"]["match_reason_code"] == MatchReasonCode.OK.value
    assert final_by_doc["d15"]["match_reason_code"] == MatchReasonCode.NO_CCM_ROW_FOR_DATE.value


def test_forward_asof_lag_gate_can_be_disabled_with_none():
    aligned = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 1)],
            "kypermno": [1],
            "phase_a_reason_code": [MatchReasonCode.OK.value],
            "data_status": [0],
            "aligned_caldt": [dt.date(2024, 1, 1)],
            "alignment_lag_days": [0],
        }
    ).lazy()
    daily = pl.DataFrame(
        {
            "KYPERMNO": [1, 1],
            "CALDT": [dt.date(2023, 12, 25), dt.date(2024, 1, 16)],
            "RET": [0.0, 0.01],
        }
    ).lazy()

    out = join_daily_phase_b(
        aligned,
        daily,
        SecCcmJoinSpecV2(
            phase_b_daily_join_mode=PhaseBDailyJoinMode.ASOF_FORWARD,
            required_daily_non_null_features=("RET",),
            daily_join_max_forward_lag_days=None,
        ),
    ).collect().row(0, named=True)

    assert out["daily_join_lag_days"] == 15
    assert out["daily_lag_gate_rejected"] is False
    assert out["_has_usable_daily_row"] is True
    assert out["data_status"] & int(DataStatus.SEC_CCM_PHASE_B_DAILY_ROW_FOUND)


def test_unmatched_diagnostics_use_aligned_date_for_key_coverage_flags():
    final_doc = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 1)],
            "match_reason_code": [MatchReasonCode.OUT_OF_CCM_COVERAGE.value],
            "phase_a_reason_code": [MatchReasonCode.OK.value],
            "phase_b_reason_code": [MatchReasonCode.OUT_OF_CCM_COVERAGE.value],
            "gvkey": ["1000"],
            "kypermno": [1],
            "link_candidate_count": [1],
            "top_rank_tie_count": [1],
            "aligned_caldt": [dt.date(2024, 1, 10)],
            "alignment_lag_days": [9],
            "key_min_caldt": [dt.date(2024, 1, 1)],
            "key_max_caldt": [dt.date(2024, 1, 5)],
            "_has_daily_row": [False],
            "_daily_row_failed_required_features": [False],
            "_missing_required_daily_feature_count": [0],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
        ]
    )

    out = build_unmatched_diagnostics_doc(
        final_doc.lazy(),
        link_universe.lazy(),
        pl.DataFrame(schema={"KYPERMNO": pl.Int32, "CALDT": pl.Date}).lazy(),
    ).collect().row(0, named=True)

    assert out["diag_aligned_before_key_coverage"] is False
    assert out["diag_aligned_after_key_coverage"] is True


def test_unmatched_diagnostics_surface_daily_row_feature_failures():
    final_doc = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 2)],
            "match_reason_code": [MatchReasonCode.REQUIRED_DAILY_FEATURE_MISSING.value],
            "phase_a_reason_code": [MatchReasonCode.OK.value],
            "phase_b_reason_code": [MatchReasonCode.REQUIRED_DAILY_FEATURE_MISSING.value],
            "gvkey": ["1000"],
            "kypermno": [1],
            "link_candidate_count": [1],
            "top_rank_tie_count": [1],
            "aligned_caldt": [dt.date(2024, 1, 3)],
            "alignment_lag_days": [1],
            "key_min_caldt": [dt.date(2024, 1, 3)],
            "key_max_caldt": [dt.date(2024, 1, 3)],
            "_has_daily_row": [True],
            "_daily_row_failed_required_features": [True],
            "_missing_required_daily_feature_count": [1],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
        ]
    )

    out = build_unmatched_diagnostics_doc(
        final_doc.lazy(),
        link_universe.lazy(),
        pl.DataFrame(schema={"KYPERMNO": pl.Int32, "CALDT": pl.Date}).lazy(),
    ).collect().row(0, named=True)

    assert out["diag_has_daily_row"] is True
    assert out["diag_daily_row_failed_required_features"] is True
    assert out["diag_missing_required_daily_feature_count"] == 1


def test_acceptance_datetime_optional_and_not_default_coerced():
    without_acceptance = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 2)],
        }
    )
    out1 = normalize_sec_filings_phase_a(without_acceptance.lazy()).collect()
    assert out1.select("acceptance_datetime").item() is None
    assert out1.select("has_acceptance_datetime").item() is False

    with_acceptance = pl.DataFrame(
        {
            "doc_id": ["d1", "d2"],
            "cik_10": ["0000000001", "0000000002"],
            "filing_date": [dt.date(2024, 1, 2), dt.date(2024, 1, 2)],
            "acceptance_datetime": [dt.datetime(2024, 1, 2, 17, 30), None],
        }
    )
    out2 = normalize_sec_filings_phase_a(with_acceptance.lazy()).collect().sort("doc_id")
    assert out2.select("acceptance_datetime").to_series().to_list() == [dt.datetime(2024, 1, 2, 17, 30), None]
    assert out2.select("has_acceptance_datetime").to_series().to_list() == [True, False]


def test_apply_concept_filter_flags_doc_requires_required_columns():
    base = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "data_status": [0],
            "PRC": [10.0],
        }
    )
    with pytest.raises(ValueError, match="concept filter input"):
        apply_concept_filter_flags_doc(base.lazy()).collect()


def test_apply_concept_filter_flags_doc_sets_flags_with_complete_inputs():
    base = pl.DataFrame(
        {
            "doc_id": ["pass", "fail"],
            "data_status": [0, 0],
            "PRC": [10.0, 0.5],
            "SHRCD": [10, 12],
            "EXCHCD": [1, 4],
            "VOL": [1000.0, 0.0],
            "TCAP": [100_000_000.0, 10_000_000.0],
        }
    )
    out = apply_concept_filter_flags_doc(base.lazy()).collect().sort("doc_id")

    assert out.select("passes_all_filters").to_series().to_list() == [False, True]
    pass_status = out.filter(pl.col("doc_id") == "pass").select("data_status").item()
    fail_status = out.filter(pl.col("doc_id") == "fail").select("data_status").item()

    assert pass_status & int(DataStatus.SEC_CCM_FILTER_PRICE_PASS)
    assert pass_status & int(DataStatus.SEC_CCM_FILTER_COMMON_STOCK_PASS)
    assert pass_status & int(DataStatus.SEC_CCM_FILTER_MAJOR_EXCHANGE_PASS)
    assert pass_status & int(DataStatus.SEC_CCM_FILTER_LIQUIDITY_PASS)
    assert pass_status & int(DataStatus.SEC_CCM_FILTER_NON_MICROCAP_PASS)
    assert pass_status & int(DataStatus.SEC_CCM_FILTER_ALL_PASS)
    assert fail_status == 0


def test_end_to_end_pipeline_outputs_doc_grain_artifacts(tmp_path: Path):
    sec = pl.DataFrame(
        {
            "doc_id": ["d1", "d2", "d3"],
            "cik_10": ["0000000001", "0000000002", "bad"],
            "filing_date": [dt.date(2024, 1, 2), dt.date(2024, 1, 4), dt.date(2024, 1, 2)],
            "document_type_filename": ["10-K", "10-K", "10-K"],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
            {"cik_10": "0000000002", "gvkey": "2000", "kypermno": 2},
        ]
    )
    trading_calendar = pl.DataFrame({"CALDT": [dt.date(2024, 1, 3), dt.date(2024, 1, 4)]})
    daily = pl.DataFrame(
        {
            "KYPERMNO": [1],
            "CALDT": [dt.date(2024, 1, 3)],
            "RET": [0.01],
            "RETX": [0.01],
            "PRC": [10.0],
            "BIDLO": [9.5],
            "ASKHI": [10.5],
            "TICKER": ["ALFA"],
            "SHRCD": [10],
            "EXCHCD": [1],
            "VOL": [1000.0],
            "TCAP": [100_000_000.0],
        }
    )

    paths = run_sec_ccm_premerge_pipeline(
        sec.lazy(),
        link_universe.lazy(),
        trading_calendar.lazy(),
        tmp_path,
        daily_lf=daily.lazy(),
        join_spec=SecCcmJoinSpecV1(required_daily_non_null_features=("RET",)),
    )

    required_keys = {
        "sec_ccm_links_doc",
        "final_flagged_data",
        "sec_ccm_match_status",
        "sec_ccm_matched_filings",
        "sec_ccm_unmatched_filings",
        "sec_ccm_unmatched_diagnostics",
        "sec_ccm_matched_clean",
        "sec_ccm_matched_clean_filtered",
        "sec_ccm_analysis_doc_ids",
        "sec_ccm_diagnostic_doc_ids",
        "sec_ccm_join_spec_v1",
        "sec_ccm_run_steps",
        "sec_ccm_run_dag_mermaid",
        "sec_ccm_run_dag_dot",
        "sec_ccm_run_manifest",
        "sec_ccm_run_report",
    }
    assert required_keys.issubset(paths.keys())
    for key, path in paths.items():
        assert Path(path).exists(), key

    final_df = pl.read_parquet(paths["final_flagged_data"])
    status_df = pl.read_parquet(paths["sec_ccm_match_status"])
    matched_df = pl.read_parquet(paths["sec_ccm_matched_clean"])
    unmatched_df = pl.read_parquet(paths["sec_ccm_unmatched_filings"])
    unmatched_diag_df = pl.read_parquet(paths["sec_ccm_unmatched_diagnostics"])

    assert final_df.height == sec.height
    assert final_df["doc_id"].n_unique() == sec.height
    assert status_df.height == sec.height
    assert status_df["doc_id"].n_unique() == sec.height
    assert "TICKER" in final_df.columns
    assert "TICKER" in matched_df.columns
    assert "TICKER" in unmatched_df.columns
    assert "TICKER" not in status_df.columns
    assert matched_df.filter(pl.col("doc_id") == "d1").select("TICKER").item() == "ALFA"
    assert unmatched_df.filter(pl.col("doc_id") == "d2").select("TICKER").item() is None
    assert final_df.schema["kypermno"] == pl.Int32
    assert final_df.schema["data_status"] == STATUS_DTYPE
    assert final_df.select(pl.col("data_status").is_null().any()).item() is False
    expected_status = build_match_status_doc(final_df.lazy()).collect().sort("doc_id")
    actual_status = status_df.sort("doc_id")
    assert expected_status.columns == actual_status.columns
    assert expected_status.to_dicts() == actual_status.to_dicts()
    assert {
        "diag_aligned_before_key_coverage",
        "diag_aligned_after_key_coverage",
        "diag_has_daily_row",
        "diag_daily_row_failed_required_features",
        "diag_missing_required_daily_feature_count",
    }.issubset(set(unmatched_diag_df.columns))

    run_steps_df = pl.read_parquet(paths["sec_ccm_run_steps"]).sort("step_order")
    assert run_steps_df.height > 0
    assert {"run_id", "step_name", "duration_ms", "step_order"}.issubset(run_steps_df.columns)
    assert run_steps_df.select((pl.col("duration_ms") >= 0).all()).item() is True

    dag_mermaid = Path(paths["sec_ccm_run_dag_mermaid"]).read_text(encoding="utf-8")
    dag_dot = Path(paths["sec_ccm_run_dag_dot"]).read_text(encoding="utf-8")
    assert "graph TD" in dag_mermaid
    assert "digraph sec_ccm_premerge_run" in dag_dot

    manifest = json.loads(Path(paths["sec_ccm_run_manifest"]).read_text(encoding="utf-8"))
    assert manifest["pipeline_name"] == "sec_ccm_premerge"
    assert manifest["summary"]["n_docs_total"] == sec.height
    assert manifest["join_spec"]["version"] == "v2"
    assert manifest["join_spec"]["phase_b_alignment_mode"] == "NEXT_TRADING_DAY_STRICT"
    assert manifest["join_spec"]["phase_b_daily_join_mode"] == "ASOF_FORWARD"
    assert manifest["join_spec"]["daily_join_max_forward_lag_days"] == 14
    assert manifest["summary"]["n_daily_lag_gate_rejected"] == 0
    assert "sec_ccm_match_status" in manifest["artifacts"]

    join_spec_payload = json.loads(Path(paths["sec_ccm_join_spec_v1"]).read_text(encoding="utf-8"))
    assert join_spec_payload["version"] == "v2"
    assert join_spec_payload["phase_b_alignment_mode"] == "NEXT_TRADING_DAY_STRICT"
    assert join_spec_payload["phase_b_daily_join_mode"] == "ASOF_FORWARD"
    assert join_spec_payload["daily_join_max_forward_lag_days"] == 14

    report_text = Path(paths["sec_ccm_run_report"]).read_text(encoding="utf-8")
    assert "SEC-CCM Pre-Merge Run Report" in report_text
    assert "Step Performance" in report_text
    assert "phase_b_alignment_mode" in report_text
    assert "phase_b_daily_join_mode" in report_text


def test_end_to_end_pipeline_matches_phase_b_surface_projection(tmp_path: Path) -> None:
    sec = pl.DataFrame(
        {
            "doc_id": ["d1", "d2"],
            "cik_10": ["0000000001", "0000000002"],
            "filing_date": [dt.date(2024, 1, 2), dt.date(2024, 1, 4)],
            "document_type_filename": ["10-K", "10-K"],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
            {"cik_10": "0000000002", "gvkey": "2000", "kypermno": 2},
        ]
    )
    trading_calendar = pl.DataFrame({"CALDT": [dt.date(2024, 1, 3), dt.date(2024, 1, 4)]})
    legacy_daily = pl.DataFrame(
        {
            "KYPERMNO": [1, 2],
            "CALDT": [dt.date(2024, 1, 3), dt.date(2024, 1, 4)],
            "RET": [0.01, 0.02],
            "RETX": [0.01, 0.02],
            "PRC": [10.0, 20.0],
            "FINAL_PRC": [10.0, 20.0],
            "BIDLO": [9.5, 19.5],
            "ASKHI": [10.5, 20.5],
            "VOL": [1000.0, 2000.0],
            "TCAP": [100_000_000.0, 200_000_000.0],
            "SHROUT": [10_000.0, 20_000.0],
            "TICKER": ["ALFA", "BETA"],
            "SHRCD": [10, 11],
            "EXCHCD": [1, 2],
            "KYGVKEY_final": ["1000", "2000"],
            "LIID": ["A", "B"],
            "CIK_final": ["0000000001", "0000000002"],
            "CUSIP": ["11111111", "22222222"],
            "ISIN": ["US1111111111", "US2222222222"],
            "LINKTYPE": ["LC", "LC"],
            "LINKPRIM": ["P", "P"],
            "link_quality_flag": ["canonical_primary_LC", "canonical_primary_LC"],
            "HEXCNTRY": ["US", "US"],
            "n_filings": [1, 1],
        }
    )
    phase_b_daily = project_ccm_daily_phase_b_surface(legacy_daily.lazy())
    join_spec = SecCcmJoinSpecV2(
        daily_join_source="MERGED_DAILY_PANEL",
        daily_feature_columns=SEC_CCM_PHASE_B_DAILY_FEATURE_COLUMNS,
        required_daily_non_null_features=("RET",),
    )

    legacy_paths = run_sec_ccm_premerge_pipeline(
        sec.lazy(),
        link_universe.lazy(),
        trading_calendar.lazy(),
        tmp_path / "legacy",
        daily_lf=legacy_daily.lazy(),
        join_spec=join_spec,
        emit_run_report=False,
    )
    phase_surface_paths = run_sec_ccm_premerge_pipeline(
        sec.lazy(),
        link_universe.lazy(),
        trading_calendar.lazy(),
        tmp_path / "phase_surface",
        daily_lf=phase_b_daily,
        join_spec=join_spec,
        emit_run_report=False,
    )

    for artifact_name in (
        "final_flagged_data",
        "sec_ccm_match_status",
        "sec_ccm_matched_clean",
        "sec_ccm_matched_clean_filtered",
        "sec_ccm_analysis_doc_ids",
        "sec_ccm_diagnostic_doc_ids",
    ):
        legacy_df = pl.read_parquet(legacy_paths[artifact_name]).sort("doc_id")
        phase_surface_df = pl.read_parquet(phase_surface_paths[artifact_name]).sort("doc_id")
        assert legacy_df.columns == phase_surface_df.columns
        assert legacy_df.to_dicts() == phase_surface_df.to_dicts()


def test_end_to_end_pipeline_daily_join_disabled_sets_filter_columns_false(tmp_path: Path):
    sec = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 2)],
            "document_type_filename": ["10-K"],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
        ]
    )
    trading_calendar = pl.DataFrame({"CALDT": [dt.date(2024, 1, 3)]})

    paths = run_sec_ccm_premerge_pipeline(
        sec.lazy(),
        link_universe.lazy(),
        trading_calendar.lazy(),
        tmp_path,
        daily_lf=None,
        join_spec=SecCcmJoinSpecV1(daily_join_enabled=False),
        emit_run_report=False,
    )

    final_df = pl.read_parquet(paths["final_flagged_data"])
    assert final_df.select("filter_price_pass").item() is False
    assert final_df.select("filter_common_stock_pass").item() is False
    assert final_df.select("filter_major_exchange_pass").item() is False
    assert final_df.select("filter_liquidity_pass").item() is False
    assert final_df.select("filter_non_microcap_pass").item() is False
    assert final_df.select("passes_all_filters").item() is False


def test_pipeline_rejects_first_close_after_acceptance_v1(tmp_path: Path):
    sec = pl.DataFrame(
        {
            "doc_id": ["d1"],
            "cik_10": ["0000000001"],
            "filing_date": [dt.date(2024, 1, 2)],
        }
    )
    link_universe = _canonical_links(
        [
            {"cik_10": "0000000001", "gvkey": "1000", "kypermno": 1},
        ]
    )
    trading_calendar = pl.DataFrame({"CALDT": [dt.date(2024, 1, 3)]})

    with pytest.raises(ValueError, match="FIRST_CLOSE_AFTER_ACCEPTANCE"):
        run_sec_ccm_premerge_pipeline(
            sec.lazy(),
            link_universe.lazy(),
            trading_calendar.lazy(),
            tmp_path,
            daily_lf=None,
            join_spec=SecCcmJoinSpecV1(
                alignment_policy="FIRST_CLOSE_AFTER_ACCEPTANCE",
                daily_join_enabled=False,
            ),
            emit_run_report=False,
        )
