from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tools import docs_check, docs_pipeline
import scaffold_docs


def _write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def _module_page_relpath(module_name: str, package_root: str = "thesis_pkg") -> str:
    return docs_check._module_to_doc_relpath(module_name=module_name, package_root=package_root)


def _build_sample_layout(tmp_path: Path) -> dict[str, Path]:
    repo_root = tmp_path
    docs_dir = repo_root / "docs"
    metadata_dir = repo_root / "docs_metadata"
    trace_dir = metadata_dir / "behavior"
    publish_dir = docs_dir / "assets" / "behavior"
    src_dir = repo_root / "src" / "thesis_pkg"
    docs_dir.mkdir(parents=True, exist_ok=True)
    metadata_dir.mkdir(parents=True, exist_ok=True)
    trace_dir.mkdir(parents=True, exist_ok=True)
    publish_dir.mkdir(parents=True, exist_ok=True)
    src_dir.mkdir(parents=True, exist_ok=True)
    (src_dir / "__init__.py").write_text("# sample\n", encoding="utf-8")
    (src_dir / "pipeline.py").write_text("def run() -> None:\n    return None\n", encoding="utf-8")

    modules = [
        "thesis_pkg.__init__",
        "thesis_pkg.pipeline",
        "thesis_pkg.core.sec.patterns",
    ]

    inventory = {
        module: {
            "classes": [],
            "functions": [],
            "constants": [],
        }
        for module in modules
    }
    outward_api = {
        "all_outward_modules": ["thesis_pkg.pipeline"],
        "modules": {"thesis_pkg.pipeline": {"outward_reasons": ["imported_by_module"]}},
    }
    import_evidence = {"modules": {module: {"importer_count": 0} for module in modules}}

    _write_json(metadata_dir / "inventory.json", inventory)
    _write_json(metadata_dir / "outward_api.json", outward_api)
    _write_json(metadata_dir / "import_evidence.json", import_evidence)

    for module_name in modules:
        rel_path = _module_page_relpath(module_name)
        page_path = docs_dir / Path(rel_path)
        page_path.parent.mkdir(parents=True, exist_ok=True)
        page_path.write_text(f"# {module_name}\n", encoding="utf-8")

    (docs_dir / "reference" / "index.md").write_text("# API Reference\n", encoding="utf-8")
    (docs_dir / "reference" / "behavior_evidence.md").write_text("# Behavior Evidence\n", encoding="utf-8")

    nav_fragment = """- Reference:
  - Overview: reference/index.md
  - Behavior Evidence: reference/behavior_evidence.md
  - thesis_pkg: reference/__init__.md
  - core:
      - sec:
          - patterns: reference/core/sec/patterns.md
  - pipeline: reference/pipeline.md
"""
    (metadata_dir / "reference_nav.yml").write_text(nav_fragment, encoding="utf-8")

    mkdocs_text = """site_name: Test Docs
nav:
  - Home: index.md
  # BEGIN AUTO-REFERENCE-NAV
  - Reference:
      - Overview: reference/index.md
      - Behavior Evidence: reference/behavior_evidence.md
      - thesis_pkg: reference/__init__.md
      - core:
          - sec:
              - patterns: reference/core/sec/patterns.md
      - pipeline: reference/pipeline.md
  # END AUTO-REFERENCE-NAV
"""
    (repo_root / "mkdocs.yml").write_text(mkdocs_text, encoding="utf-8")

    return {
        "repo_root": repo_root,
        "docs_dir": docs_dir,
        "metadata_dir": metadata_dir,
        "trace_dir": trace_dir,
        "publish_dir": publish_dir,
        "src_dir": src_dir,
        "mkdocs": repo_root / "mkdocs.yml",
    }


def test_nav_structure_check_passes_with_formatting_differences(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=False,
    )

    assert errors == []


def test_generate_reference_docs_skips_mkdocstrings_for_non_importable_script_module(
    tmp_path: Path,
) -> None:
    docs_dir = tmp_path / "docs"
    metadata_dir = tmp_path / "docs_metadata"
    docs_dir.mkdir(parents=True, exist_ok=True)
    metadata_dir.mkdir(parents=True, exist_ok=True)

    def _module_entry(path: str) -> dict[str, object]:
        return {
            "path": path,
            "docstring": None,
            "has_docstring": False,
            "has_all": False,
            "classes": [],
            "functions": [],
            "constants": [],
            "re_exports": [],
        }

    inventory = {
        "thesis_pkg.__init__": _module_entry("thesis_pkg/__init__.py"),
        "thesis_pkg.pipeline": _module_entry("thesis_pkg/pipeline.py"),
        "thesis_pkg.notebooks_and_scripts.sec_ccm_unified_runner": _module_entry(
            "thesis_pkg/notebooks_and_scripts/sec_ccm_unified_runner.py"
        ),
    }
    outward_api = {"all_outward_modules": [], "modules": {}}
    import_evidence = {"modules": {}}

    _write_json(metadata_dir / "inventory.json", inventory)
    _write_json(metadata_dir / "outward_api.json", outward_api)
    _write_json(metadata_dir / "import_evidence.json", import_evidence)

    scaffold_docs.generate_reference_docs(
        inventory_file=metadata_dir / "inventory.json",
        outward_api_file=metadata_dir / "outward_api.json",
        import_evidence_file=metadata_dir / "import_evidence.json",
        docs_dir=docs_dir,
        package_root="thesis_pkg",
    )

    importable_page = (docs_dir / "reference" / "pipeline.md").read_text(encoding="utf-8")
    script_page = (
        docs_dir / "reference" / "notebooks_and_scripts" / "sec_ccm_unified_runner.md"
    ).read_text(encoding="utf-8")

    assert "::: thesis_pkg.pipeline" in importable_page
    assert "mkdocstrings rendering is skipped" in script_page.lower()
    assert "::: thesis_pkg.notebooks_and_scripts.sec_ccm_unified_runner" not in script_page


def test_nav_structure_check_fails_on_mismatch(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    mkdocs_mismatch = """site_name: Test Docs
nav:
  - Home: index.md
  # BEGIN AUTO-REFERENCE-NAV
  - Reference:
      - Overview: reference/index.md
      - Behavior Evidence: reference/behavior_evidence.md
      - thesis_pkg: reference/__init__.md
      - core:
          - sec:
              - wrong_label: reference/core/sec/patterns.md
      - pipeline: reference/pipeline.md
  # END AUTO-REFERENCE-NAV
"""
    layout["mkdocs"].write_text(mkdocs_mismatch, encoding="utf-8")

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=False,
    )

    assert any("does not match generated nav fragment" in message for message in errors)


def test_nav_fragment_requires_behavior_evidence_entry(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    nav_fragment_without_behavior = """- Reference:
  - Overview: reference/index.md
  - thesis_pkg: reference/__init__.md
  - core:
      - sec:
          - patterns: reference/core/sec/patterns.md
  - pipeline: reference/pipeline.md
"""
    (layout["metadata_dir"] / "reference_nav.yml").write_text(nav_fragment_without_behavior, encoding="utf-8")

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=False,
    )

    assert any("reference/behavior_evidence.md" in message for message in errors)


def test_freshness_gate_flags_stale_metadata(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    now = time.time()
    stale = now - 200
    fresh = now + 200

    metadata_files = [
        layout["metadata_dir"] / "inventory.json",
        layout["metadata_dir"] / "outward_api.json",
        layout["metadata_dir"] / "import_evidence.json",
        layout["metadata_dir"] / "reference_nav.yml",
    ]
    for path in metadata_files:
        os.utime(path, (stale, stale))

    source_file = layout["src_dir"] / "pipeline.py"
    os.utime(source_file, (fresh, fresh))

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=False,
    )

    assert any("Docs metadata appears stale" in message for message in errors)


def test_require_trace_fails_without_manifest(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=True,
    )

    assert any("Missing trace manifest" in message for message in errors)


def test_require_trace_passes_with_manifest_and_artifacts(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    trace_artifact = layout["trace_dir"] / "artifact_manifest.csv"
    trace_artifact.write_text("k,v\n", encoding="utf-8")
    published_artifact = layout["publish_dir"] / "artifact_manifest.csv"
    published_artifact.write_text("k,v\n", encoding="utf-8")
    preview_artifact = layout["publish_dir"] / "artifact_manifest.csv.preview.html"
    preview_artifact.write_text("<html></html>\n", encoding="utf-8")
    _write_json(
        layout["trace_dir"] / "run_manifest.json",
        {
            "trace_generation": {"allow_missing_canonical": False},
            "artifacts": [
                {
                    "artifact_key": "artifact_manifest_csv",
                    "canonical_path": str(trace_artifact.relative_to(layout["repo_root"])).replace("\\", "/"),
                    "published_path": str(published_artifact.relative_to(layout["repo_root"])).replace("\\", "/"),
                    "published_doc_path": "assets/behavior/artifact_manifest.csv",
                    "preview_path": str(preview_artifact.relative_to(layout["repo_root"])).replace("\\", "/"),
                    "preview_doc_path": "assets/behavior/artifact_manifest.csv.preview.html",
                    "publish_status": "published",
                    "publish_note": "",
                },
                {
                    "artifact_key": "omitted_non_tabular",
                    "canonical_path": str(trace_artifact.relative_to(layout["repo_root"])).replace("\\", "/"),
                    "published_path": "",
                    "published_doc_path": "",
                    "preview_path": "",
                    "preview_doc_path": "",
                    "publish_status": "omitted_size_limit",
                    "publish_note": "OMITTED_SIZE_LIMIT",
                }
            ]
        },
    )

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=True,
    )

    assert errors == []


def test_require_trace_respects_missing_canonical_override(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    published_artifact = layout["publish_dir"] / "artifact_manifest.csv"
    published_artifact.write_text("k,v\n", encoding="utf-8")
    _write_json(
        layout["trace_dir"] / "run_manifest.json",
        {
            "trace_generation": {"allow_missing_canonical": True},
            "artifacts": [
                {
                    "artifact_key": "missing_canonical_allowed",
                    "canonical_path": "docs_metadata/behavior/does_not_exist.csv",
                    "published_path": "",
                    "published_doc_path": "",
                    "preview_path": "",
                    "preview_doc_path": "",
                    "publish_status": "omitted_size_limit",
                    "publish_note": "MISSING_CANONICAL_ALLOWED",
                },
                {
                    "artifact_key": "published_ok",
                    "canonical_path": str((layout["trace_dir"] / "dummy.csv").relative_to(layout["repo_root"])).replace("\\", "/"),
                    "published_path": str(published_artifact.relative_to(layout["repo_root"])).replace("\\", "/"),
                    "published_doc_path": "assets/behavior/artifact_manifest.csv",
                    "preview_path": "",
                    "preview_doc_path": "",
                    "publish_status": "published",
                    "publish_note": "",
                },
            ],
        },
    )
    (layout["trace_dir"] / "dummy.csv").write_text("k,v\n", encoding="utf-8")

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=True,
    )
    assert errors == []


def test_require_trace_fails_when_published_status_missing_target(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    trace_artifact = layout["trace_dir"] / "artifact_manifest.csv"
    trace_artifact.write_text("k,v\n", encoding="utf-8")
    _write_json(
        layout["trace_dir"] / "run_manifest.json",
        {
            "trace_generation": {"allow_missing_canonical": False},
            "artifacts": [
                {
                    "artifact_key": "bad_published",
                    "canonical_path": str(trace_artifact.relative_to(layout["repo_root"])).replace("\\", "/"),
                    "published_path": "",
                    "published_doc_path": "",
                    "preview_path": "",
                    "preview_doc_path": "",
                    "publish_status": "published",
                    "publish_note": "",
                }
            ],
        },
    )

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=True,
    )
    assert any("invalid published artifact references" in message for message in errors)


def test_behavior_page_link_check_rejects_docs_metadata_links(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    (layout["docs_dir"] / "reference" / "behavior_evidence.md").write_text(
        (
            "# Behavior Evidence\n\n"
            "- bad: [docs_metadata/behavior/run_manifest.json](../../docs_metadata/behavior/run_manifest.json)\n"
        ),
        encoding="utf-8",
    )

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=False,
    )
    assert any("targets docs_metadata" in message for message in errors)


def test_behavior_page_link_check_accepts_assets_links(tmp_path: Path) -> None:
    layout = _build_sample_layout(tmp_path)
    asset = layout["publish_dir"] / "artifact_manifest.csv"
    asset.write_text("k,v\n", encoding="utf-8")
    (layout["docs_dir"] / "reference" / "behavior_evidence.md").write_text(
        (
            "# Behavior Evidence\n\n"
            "- ok: [assets/behavior/artifact_manifest.csv](../assets/behavior/artifact_manifest.csv)\n"
        ),
        encoding="utf-8",
    )

    errors = docs_check.check_docs(
        repo_root=layout["repo_root"],
        src_dir=layout["src_dir"],
        inventory_path=layout["metadata_dir"] / "inventory.json",
        outward_api_path=layout["metadata_dir"] / "outward_api.json",
        import_evidence_path=layout["metadata_dir"] / "import_evidence.json",
        nav_fragment_path=layout["metadata_dir"] / "reference_nav.yml",
        mkdocs_config_path=layout["mkdocs"],
        docs_dir=layout["docs_dir"],
        trace_dir=layout["trace_dir"],
        package_root="thesis_pkg",
        run_build=False,
        require_trace=False,
    )
    assert errors == []


def test_reference_only_warning_gate_mixed_entries() -> None:
    log_text = """
WARNING -  The following pages exist in the docs directory, but are not included in the "nav" configuration:
  - docstring_audit_report.md
  - other/legacy.md
  - reference/core/sec/patterns.md
"""
    pages = docs_check.extract_not_in_nav_pages(log_text)
    offenders = docs_check.reference_only_missing_pages(pages)
    assert offenders == ["reference/core/sec/patterns.md"]


def test_reference_only_warning_gate_ignores_non_reference() -> None:
    log_text = """
WARNING -  The following pages exist in the docs directory, but are not included in the "nav" configuration:
  - docstring_audit_report.md
  - other/legacy.md
"""
    pages = docs_check.extract_not_in_nav_pages(log_text)
    offenders = docs_check.reference_only_missing_pages(pages)
    assert offenders == []


def test_pipeline_build_env_sets_utf8_on_windows() -> None:
    env = docs_pipeline.build_subprocess_env(
        base_env={"PATH": "X"},
        enforce_mkdocs_utf8=True,
        os_name="nt",
    )
    assert env["PYTHONIOENCODING"] == "utf-8"


def test_json_canonicalization_is_deterministic() -> None:
    first = '{\n  "b": 2,\n  "a": {"y": 2, "x": 1}\n}'
    second = '{"a":{"x":1,"y":2},"b":2}'
    first_canon = docs_check.canonicalize_json_text(first)
    second_canon = docs_check.canonicalize_json_text(second)
    assert first_canon == second_canon
