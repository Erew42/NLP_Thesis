"""Compatibility import surface used by ``thesis_pkg.__init__``."""

from __future__ import annotations

from thesis_pkg.core.ccm.canonical_links import (
    build_canonical_link_table,
    canonical_link_coverage_metrics,
    normalize_canonical_link_table,
)
from thesis_pkg.core.ccm.sec_ccm_contracts import (
    MatchReasonCode,
    PhaseBAlignmentMode,
    PhaseBDailyJoinMode,
    SEC_CCM_PHASE_B_DAILY_FEATURE_COLUMNS,
    SecCcmJoinSpec,
    SecCcmJoinSpecV1,
    SecCcmJoinSpecV2,
    make_sec_ccm_join_spec_preset,
    normalize_sec_ccm_join_spec,
)
from thesis_pkg.core.ccm.sec_ccm_premerge import (
    align_doc_dates_phase_b,
    apply_phase_b_reason_codes,
    build_match_status_doc,
    build_unmatched_diagnostics_doc,
    normalize_sec_filings_phase_a,
    resolve_links_phase_a,
    join_daily_phase_b,
)
from thesis_pkg.core.ccm.lm2011 import (
    attach_eligible_quarterly_accounting,
    attach_lm2011_industry_classifications,
    attach_latest_annual_accounting,
    attach_pre_filing_market_data,
    build_annual_accounting_panel,
    build_lm2011_normalized_filing_feeds,
    build_lm2011_sample_backbone,
    build_quarterly_accounting_panel,
    derive_filing_trade_anchors,
    normalize_lm2011_form_expr,
    normalize_lm2011_form_value,
)
from thesis_pkg.core.sec.lm2011_text import (
    build_lm2011_text_features_full_10k,
    build_lm2011_text_features_mda,
    normalize_lm2011_dictionary_lists,
    tokenize_lm2011_text,
)
from thesis_pkg.core.ccm.transforms import (
    CCM_DAILY_BRIDGE_SURFACE_OPTIONAL_COLUMNS,
    CCM_DAILY_BRIDGE_SURFACE_REQUIRED_COLUMNS,
    CCM_DAILY_MARKET_CORE_COLUMNS,
    CCM_DAILY_PHASE_B_SURFACE_COLUMNS,
    EXCHCD_NAME_MAP,
    SHRCD_FIRST_DIGIT_MAP,
    SHRCD_NAME_MAP,
    SHRCD_SECOND_DIGIT_MAP,
    STATUS_DTYPE,
    DataStatus,
    add_exchcd_name,
    add_final_returns,
    apply_concept_filter_flags_doc,
    filter_us_common_major_exchange,
    add_shrcd_name,
    attach_ccm_links,
    attach_company_description,
    attach_filings,
    build_price_panel,
    exchcd_name_expr,
    project_ccm_daily_bridge_surface,
    project_ccm_daily_market_core,
    project_ccm_daily_phase_b_surface,
    map_shrcd_to_name,
    shrcd_name_expr,
    map_exchcd_to_name,
)
from thesis_pkg.io.parquet import load_tables, sink_exact_firm_sample_from_parquet
from thesis_pkg.pipelines.ccm_pipeline import build_or_reuse_ccm_daily_stage, merge_histories
from thesis_pkg.pipelines.lm2011_pipeline import (
    build_lm2011_event_panel,
    build_lm2011_table_i_sample_creation,
    build_lm2011_sue_panel,
    build_lm2011_trading_strategy_ff4_summary,
    build_lm2011_trading_strategy_monthly_returns,
)
from thesis_pkg.pipelines.lm2011_regressions import (
    build_lm2011_normalized_difference_panel,
    build_lm2011_return_regression_panel,
    build_lm2011_sue_regression_panel,
    build_lm2011_table_ia_i_results,
    build_lm2011_table_ia_ii_results,
    build_lm2011_table_iv_results,
    build_lm2011_table_v_results,
    build_lm2011_table_vi_results,
    build_lm2011_table_viii_results,
    run_lm2011_quarterly_fama_macbeth,
)
from thesis_pkg.pipelines.lm2011_extension import (
    build_lm2011_extension_analysis_panel,
    build_lm2011_extension_control_ladder,
    build_lm2011_extension_dictionary_features,
    build_lm2011_extension_sample_loss_table,
    build_lm2011_extension_specification_grid,
    run_lm2011_extension_estimation_scaffold,
)
from thesis_pkg.pipelines.refinitiv import (
    build_refinitiv_analyst_normalized_outputs,
    build_refinitiv_lm2011_doc_analyst_anchors,
    build_refinitiv_lm2011_doc_ownership_requests,
    build_refinitiv_step1_analyst_request_groups,
    build_refinitiv_step1_ownership_authority_tables,
    build_refinitiv_ownership_universe_row_summary,
    build_refinitiv_step1_ownership_universe_handoff,
    build_refinitiv_step1_bridge_universe,
    build_refinitiv_step1_instrument_authority_frame,
    build_refinitiv_step1_resolution_frame,
    is_lseg_available,
    run_refinitiv_lm2011_doc_analyst_anchor_pipeline,
    run_refinitiv_lm2011_doc_analyst_select_pipeline,
    run_refinitiv_lm2011_doc_ownership_exact_api_pipeline,
    run_refinitiv_lm2011_doc_ownership_exact_handoff_pipeline,
    run_refinitiv_lm2011_doc_ownership_fallback_api_pipeline,
    run_refinitiv_lm2011_doc_ownership_fallback_handoff_pipeline,
    run_refinitiv_lm2011_doc_ownership_finalize_pipeline,
    run_refinitiv_step1_analyst_actuals_api_pipeline,
    run_refinitiv_step1_analyst_estimates_monthly_api_pipeline,
    run_refinitiv_step1_analyst_normalize_pipeline,
    run_refinitiv_step1_analyst_request_groups_pipeline,
    run_refinitiv_step1_lookup_api_pipeline,
    run_refinitiv_step1_ownership_authority_pipeline,
    run_refinitiv_step1_ownership_universe_api_pipeline,
    run_refinitiv_step1_ownership_universe_handoff_pipeline,
    run_refinitiv_step1_ownership_universe_results_pipeline,
    run_refinitiv_step1_instrument_authority_pipeline,
    run_refinitiv_step1_resolution_pipeline,
    run_refinitiv_step1_bridge_pipeline,
    select_refinitiv_lm2011_doc_analyst_inputs,
)
from thesis_pkg.pipelines.sec_ccm_pipeline import run_sec_ccm_premerge_pipeline
