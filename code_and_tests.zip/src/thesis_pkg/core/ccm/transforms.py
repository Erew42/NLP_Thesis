from __future__ import annotations

import datetime as dt
from enum import IntFlag

import polars as pl

from thesis_pkg.core.ccm.canonical_links import normalize_canonical_link_table


STATUS_DTYPE = pl.UInt64

EXCHCD_NAME_MAP: dict[int, str] = {
    -2: "Halted by Primary Listing Exchange",
    -1: "Suspended by Primary Listing Exchange",
    0: "Not Trading on Primary Listing Exchange",
    1: "NYSE",
    2: "NYSE MKT",
    3: "NASDAQ",
    4: "Arca",
    5: "BZX Exchange",
    6: "Investors Exchange (IEX)",
    10: "Boston Stock Exchange",
    13: "Chicago Stock Exchange",
    16: "Pacific Stock Exchange",
    17: "Philadelphia Stock Exchange",
    20: "Over-The-Counter (Non-NASDAQ Dealer Quotations)",
    31: "When-Issued Trading on NYSE",
    32: "When-Issued Trading on NYSE MKT",
    33: "When-Issued Trading on NASDAQ",
}

SHRCD_FIRST_DIGIT_MAP: dict[int, str] = {
    1: "Ordinary Common Shares",
    2: "Certificates, Americus Trust Components (Prime, Score, & Units)",
    3: "ADRs (American Depositary Receipts)",
    4: "SBIs (Shares of Beneficial Interest)",
    7: "Units / Depositary Units / Limited Partnership Interests / ETFs",
}

SHRCD_SECOND_DIGIT_MAP: dict[int, str] = {
    0: "Securities which have not been further defined",
    1: "Securities which need not be further defined",
    2: "Companies incorporated outside the US",
    3: "Americus Trust Components / ETFs",
    4: "Closed-end funds",
    5: "Closed-end fund companies incorporated outside the US",
    8: "REITs (Real Estate Investment Trusts)",
}

SHRCD_NAME_MAP: dict[int, str] = {
    first_digit * 10 + second_digit: f"{first_desc} | {second_desc}"
    for first_digit, first_desc in SHRCD_FIRST_DIGIT_MAP.items()
    for second_digit, second_desc in SHRCD_SECOND_DIGIT_MAP.items()
}

CCM_DAILY_MARKET_CORE_COLUMNS: tuple[str, ...] = (
    "KYPERMNO",
    "CALDT",
    "PRC",
    "RET",
    "RETX",
    "TCAP",
    "VOL",
    "BIDLO",
    "ASKHI",
    "BID",
    "ASK",
    "NUMTRD",
    "OPENPRC",
    "data_status",
    "SHROUT",
    "TICKER",
    "SHRCD",
    "EXCHCD",
    "PRIMEXCH",
    "TRDSTAT",
    "SECSTAT",
    "DLSTDT",
    "DLSTCD",
    "DLPRC",
    "DLAMT",
    "DLRET",
    "DLRETX",
    "FINAL_RET",
    "FINAL_RETX",
    "FINAL_PRC",
    "filter_price_pass",
    "filter_common_stock_pass",
    "filter_major_exchange_pass",
    "filter_liquidity_pass",
    "filter_non_microcap_pass",
    "passes_all_filters",
)

CCM_DAILY_PHASE_B_SURFACE_COLUMNS: tuple[str, ...] = (
    "KYPERMNO",
    "CALDT",
    "RET",
    "RETX",
    "PRC",
    "FINAL_PRC",
    "BIDLO",
    "ASKHI",
    "VOL",
    "TCAP",
    "SHROUT",
    "TICKER",
    "SHRCD",
    "EXCHCD",
)

CCM_DAILY_BRIDGE_SURFACE_REQUIRED_COLUMNS: tuple[str, ...] = (
    "KYPERMNO",
    "CALDT",
    "KYGVKEY_final",
    "LIID",
    "CIK_final",
    "CUSIP",
    "ISIN",
    "TICKER",
    "SHRCD",
)

CCM_DAILY_BRIDGE_SURFACE_OPTIONAL_COLUMNS: tuple[str, ...] = (
    "LINKTYPE",
    "LINKPRIM",
    "link_quality_flag",
    "HEXCNTRY",
    "n_filings",
)


class DataStatus(IntFlag):
    """Bitmask for data availability, provenance, and join results."""

    NONE = 0

    # Core Data Availability (Used in build_price_panel)
    HAS_RET = 1 << 0
    HAS_BIDLO = 1 << 1

    # Detailed Provenance (Used in add_final_returns)
    HAS_RETX = 1 << 2
    HAS_PRC = 1 << 3
    HAS_DLRET = 1 << 4
    HAS_DLRETX = 1 << 5
    HAS_DLPRC = 1 << 6

    # Company history diagnostics
    COMPHIST_CAN_ATTEMPT = 1 << 7
    COMPHIST_ATTEMPTED = 1 << 8
    COMPHIST_MATCHED = 1 << 9
    COMPHIST_NO_MATCH = 1 << 10
    COMPHIST_VALID = 1 << 11
    COMPHIST_STALE = 1 << 12

    # Security history diagnostics
    SECHIST_CAN_ATTEMPT = 1 << 13
    SECHIST_ATTEMPTED = 1 << 14
    SECHIST_MATCHED = 1 << 15
    SECHIST_NO_MATCH = 1 << 16
    SECHIST_VALID = 1 << 17
    SECHIST_STALE = 1 << 18

    # Auxiliary metadata
    HAS_COMP_DESC = 1 << 19

    # SEC-CCM Phase A linking diagnostics
    SEC_CCM_PHASE_A_ATTEMPTED = 1 << 20
    SEC_CCM_BAD_INPUT = 1 << 21
    SEC_CCM_CIK_NOT_IN_LINK_UNIVERSE = 1 << 22
    SEC_CCM_AMBIGUOUS_LINK = 1 << 23
    SEC_CCM_LINKED_OK = 1 << 24
    SEC_CCM_HAS_ACCEPTANCE_DATETIME = 1 << 25

    # SEC-CCM Phase B alignment + daily join diagnostics
    SEC_CCM_PHASE_B_ALIGNMENT_ATTEMPTED = 1 << 26
    SEC_CCM_PHASE_B_ALIGNED = 1 << 27
    SEC_CCM_PHASE_B_OUT_OF_CCM_COVERAGE = 1 << 28
    SEC_CCM_PHASE_B_DAILY_JOIN_ATTEMPTED = 1 << 29
    SEC_CCM_PHASE_B_DAILY_ROW_FOUND = 1 << 30
    SEC_CCM_PHASE_B_NO_CCM_ROW_FOR_DATE = 1 << 31

    # Concept filter pass diagnostics
    SEC_CCM_FILTER_PRICE_PASS = 1 << 32
    SEC_CCM_FILTER_COMMON_STOCK_PASS = 1 << 33
    SEC_CCM_FILTER_MAJOR_EXCHANGE_PASS = 1 << 34
    SEC_CCM_FILTER_LIQUIDITY_PASS = 1 << 35
    SEC_CCM_FILTER_NON_MICROCAP_PASS = 1 << 36
    SEC_CCM_FILTER_ALL_PASS = 1 << 37
    SEC_CCM_CIK_PRESENT_NO_POSITIVE_LINK = 1 << 38
    SEC_CCM_NO_DATE_VALID_POSITIVE_LINK = 1 << 39
    SEC_CCM_NO_ELIGIBLE_LINK_CANDIDATE = 1 << 40
    SEC_CCM_PHASE_B_REQUIRED_DAILY_FEATURE_MISSING = 1 << 41

    # Convenience Combinations for Filtering
    FULL_PANEL_DATA = HAS_RET | HAS_BIDLO
    ANY_RET_DATA = HAS_RET | HAS_DLRET
    # Convenience alias: rows where both common-stock and major-exchange pass bits are set.
    SEC_CCM_FILTER_US_COMMON_STOCK_MAJOR_EXCHANGE_PASS = (
        SEC_CCM_FILTER_COMMON_STOCK_PASS | SEC_CCM_FILTER_MAJOR_EXCHANGE_PASS
    )
    US_COMMON_STOCK_MAJOR_EXCHANGE = SEC_CCM_FILTER_US_COMMON_STOCK_MAJOR_EXCHANGE_PASS


def _normalize_form_for_match(expr: pl.Expr) -> pl.Expr:
    """Normalize SEC and CCM raw form labels to a shared match key."""
    normalized = (
        expr.cast(pl.String, strict=False)
        .str.strip_chars()
        .str.to_uppercase()
        .str.replace_all(r"[\s-]+", "")
    )
    return (
        pl.when(normalized == "10KA").then(pl.lit("10K/A"))
        .when(normalized == "10QA").then(pl.lit("10Q/A"))
        .when(normalized == "10KTA").then(pl.lit("10KT/A"))
        .when(normalized == "10QTA").then(pl.lit("10QT/A"))
        .when(normalized == "10K405A").then(pl.lit("10K405/A"))
        .otherwise(normalized)
    )


def _normalize_form_token_for_match(value: str | None) -> str | None:
    """Normalize a Python form token using the same rules as the Polars expression helper."""
    if value is None:
        return None
    normalized = value.strip().upper().replace(" ", "").replace("-", "")
    if not normalized:
        return None
    if normalized == "10KA":
        return "10K/A"
    if normalized == "10QA":
        return "10Q/A"
    if normalized == "10KTA":
        return "10KT/A"
    if normalized == "10QTA":
        return "10QT/A"
    if normalized == "10K405A":
        return "10K405/A"
    return normalized

def _ensure_data_status(lf: pl.LazyFrame) -> pl.LazyFrame:
    """Guarantee presence and dtype of the shared status column."""
    schema = lf.collect_schema()
    if "data_status" not in schema:
        return lf.with_columns(pl.lit(int(DataStatus.NONE), dtype=STATUS_DTYPE).alias("data_status"))
    return lf.with_columns(pl.col("data_status").cast(STATUS_DTYPE).fill_null(int(DataStatus.NONE)))


def _flag_if(expr: pl.Expr, flag: DataStatus) -> pl.Expr:
    """Helper to promote a boolean to a UInt64 bitmask."""
    return expr.fill_null(False).cast(STATUS_DTYPE) * int(flag)


def _update_data_status(
    base_status: pl.Expr,
    *,
    conditional_flags: tuple[tuple[pl.Expr, DataStatus], ...] = (),
    static_flags: DataStatus = DataStatus.NONE,
) -> pl.Expr:
    """Compose status updates from static and conditional flags."""
    status = base_status.cast(STATUS_DTYPE).fill_null(int(DataStatus.NONE))
    if static_flags != DataStatus.NONE:
        status = status | pl.lit(int(static_flags), dtype=STATUS_DTYPE)
    for expr, flag in conditional_flags:
        status = status | _flag_if(expr, flag)
    return status.cast(STATUS_DTYPE)


def _coerce_date(value: dt.date | dt.datetime | str) -> dt.date:
    """Normalize input to a date for filtering."""
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    return dt.date.fromisoformat(str(value))


def map_exchcd_to_name(code: int | None, *, unknown: str | None = None) -> str | None:
    """Map a CRSP exchange code to a human-readable exchange name."""
    if code is None:
        return None
    return EXCHCD_NAME_MAP.get(int(code), unknown)


def exchcd_name_expr(code_col: str = "EXCHCD", *, unknown: str | None = None) -> pl.Expr:
    """Return a Polars expression mapping EXCHCD values to exchange names."""
    code_expr = pl.col(code_col).cast(pl.Int32, strict=False)
    mapped = pl.when(code_expr.is_null()).then(pl.lit(None, dtype=pl.Utf8))
    for exch_code, exch_name in sorted(EXCHCD_NAME_MAP.items()):
        mapped = mapped.when(code_expr == pl.lit(exch_code)).then(pl.lit(exch_name, dtype=pl.Utf8))
    if unknown is None:
        return mapped.otherwise(pl.lit(None, dtype=pl.Utf8))
    return mapped.otherwise(pl.lit(unknown, dtype=pl.Utf8))


def add_exchcd_name(
    lf: pl.LazyFrame,
    *,
    code_col: str = "EXCHCD",
    out_col: str = "EXCHCD_NAME",
    unknown: str | None = None,
) -> pl.LazyFrame:
    """Add a mapped exchange-name column derived from EXCHCD."""
    return lf.with_columns(exchcd_name_expr(code_col, unknown=unknown).alias(out_col))


def map_shrcd_to_name(code: int | None, *, unknown: str | None = None) -> str | None:
    """Map a CRSP 2-digit share code to a human-readable description."""
    if code is None:
        return None
    code_int = int(code)
    return SHRCD_NAME_MAP.get(code_int, unknown)


def shrcd_name_expr(code_col: str = "SHRCD", *, unknown: str | None = None) -> pl.Expr:
    """Return a Polars expression mapping SHRCD values to a share-code description."""
    code_expr = pl.col(code_col).cast(pl.Int32, strict=False)
    first_digit = (code_expr // pl.lit(10)).cast(pl.Int32, strict=False)
    second_digit = (code_expr % pl.lit(10)).cast(pl.Int32, strict=False)

    first_desc = pl.when(first_digit == pl.lit(1)).then(pl.lit(SHRCD_FIRST_DIGIT_MAP[1], dtype=pl.Utf8))
    for k in (2, 3, 4, 7):
        first_desc = first_desc.when(first_digit == pl.lit(k)).then(pl.lit(SHRCD_FIRST_DIGIT_MAP[k], dtype=pl.Utf8))
    first_desc = first_desc.otherwise(pl.lit(None, dtype=pl.Utf8))

    second_desc = pl.when(second_digit == pl.lit(0)).then(pl.lit(SHRCD_SECOND_DIGIT_MAP[0], dtype=pl.Utf8))
    for k in (1, 2, 3, 4, 5, 8):
        second_desc = second_desc.when(second_digit == pl.lit(k)).then(
            pl.lit(SHRCD_SECOND_DIGIT_MAP[k], dtype=pl.Utf8)
        )
    second_desc = second_desc.otherwise(pl.lit(None, dtype=pl.Utf8))

    valid = first_desc.is_not_null() & second_desc.is_not_null()
    combined = pl.concat_str([first_desc, second_desc], separator=" | ")
    mapped = (
        pl.when(code_expr.is_null())
        .then(pl.lit(None, dtype=pl.Utf8))
        .when(valid)
        .then(combined)
    )
    if unknown is None:
        return mapped.otherwise(pl.lit(None, dtype=pl.Utf8))
    return mapped.otherwise(pl.lit(unknown, dtype=pl.Utf8))


def add_shrcd_name(
    lf: pl.LazyFrame,
    *,
    code_col: str = "SHRCD",
    out_col: str = "SHRCD_NAME",
    unknown: str | None = None,
) -> pl.LazyFrame:
    """Add a mapped share-code description column derived from SHRCD."""
    return lf.with_columns(shrcd_name_expr(code_col, unknown=unknown).alias(out_col))


def common_stock_pass_expr(code_col: str = "SHRCD") -> pl.Expr:
    """Return the canonical common-stock predicate (CRSP SHRCD in {10, 11})."""
    return pl.col(code_col).cast(pl.Int32, strict=False).is_in([10, 11]).fill_null(False)


def major_exchange_pass_expr(code_col: str = "EXCHCD") -> pl.Expr:
    """Return the canonical major-exchange predicate (CRSP EXCHCD in {1, 2, 3})."""
    return pl.col(code_col).cast(pl.Int32, strict=False).is_in([1, 2, 3]).fill_null(False)


def filter_us_common_major_exchange(
    lf: pl.LazyFrame,
    *,
    status_col: str = "data_status",
) -> pl.LazyFrame:
    """
    Keep rows where both US common-stock and major-exchange filter bits are set.

    This uses the canonical concept-filter status bits:
    - SEC_CCM_FILTER_COMMON_STOCK_PASS (SHRCD in {10, 11})
    - SEC_CCM_FILTER_MAJOR_EXCHANGE_PASS (EXCHCD in {1, 2, 3})
    """
    normalized = _ensure_data_status(lf)
    required_mask = int(DataStatus.US_COMMON_STOCK_MAJOR_EXCHANGE)
    status_expr = pl.col(status_col).cast(STATUS_DTYPE).fill_null(int(DataStatus.NONE))
    return normalized.filter(
        (status_expr & pl.lit(required_mask, dtype=STATUS_DTYPE)) == pl.lit(required_mask, dtype=STATUS_DTYPE)
    )


def _resolve_first_existing(schema: pl.Schema, candidates: tuple[str, ...], label: str) -> str:
    for candidate in candidates:
        if candidate in schema:
            return candidate
    raise ValueError(f"{label} missing any of expected columns: {list(candidates)}")


def apply_concept_filter_flags_doc(final_doc_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Apply concept-based filter flags without dropping rows."""
    lf = _ensure_data_status(final_doc_lf)
    schema = lf.collect_schema()
    metadata_hint = (
        "concept filter input (rebuild upstream CCM daily panel with sfz_nam/sfz_hdr enrichment, "
        "and include canonical columns in daily_feature_columns)"
    )

    price_col = _resolve_first_existing(schema, ("FINAL_PRC", "PRC", "DLPRC"), "concept filter input (price)")
    shrcd_col = _resolve_first_existing(schema, ("SHRCD",), f"{metadata_hint} (SHRCD)")
    exchcd_col = _resolve_first_existing(schema, ("EXCHCD",), f"{metadata_hint} (EXCHCD)")
    vol_col = _resolve_first_existing(schema, ("VOL",), f"{metadata_hint} (VOL)")
    market_cap_col = _resolve_first_existing(schema, ("TCAP",), "concept filter input (TCAP market cap)")

    price_ok = (pl.col(price_col).abs().cast(pl.Float64, strict=False) >= pl.lit(1.0)).fill_null(False)
    common_stock_ok = common_stock_pass_expr(shrcd_col)
    major_exchange_ok = major_exchange_pass_expr(exchcd_col)
    liquidity_ok = (pl.col(vol_col).cast(pl.Float64, strict=False).fill_null(0.0) > pl.lit(0.0)).fill_null(False)
    non_microcap_ok = (
        pl.col(market_cap_col).cast(pl.Float64, strict=False).fill_null(0.0) >= pl.lit(50_000_000.0)
    ).fill_null(False)
    passes_all = price_ok & common_stock_ok & major_exchange_ok & liquidity_ok & non_microcap_ok

    status = _update_data_status(
        pl.col("data_status"),
        conditional_flags=(
            (price_ok, DataStatus.SEC_CCM_FILTER_PRICE_PASS),
            (common_stock_ok, DataStatus.SEC_CCM_FILTER_COMMON_STOCK_PASS),
            (major_exchange_ok, DataStatus.SEC_CCM_FILTER_MAJOR_EXCHANGE_PASS),
            (liquidity_ok, DataStatus.SEC_CCM_FILTER_LIQUIDITY_PASS),
            (non_microcap_ok, DataStatus.SEC_CCM_FILTER_NON_MICROCAP_PASS),
            (passes_all, DataStatus.SEC_CCM_FILTER_ALL_PASS),
        ),
    ).alias("data_status")

    return lf.with_columns(
        price_ok.alias("filter_price_pass"),
        common_stock_ok.alias("filter_common_stock_pass"),
        major_exchange_ok.alias("filter_major_exchange_pass"),
        liquidity_ok.alias("filter_liquidity_pass"),
        non_microcap_ok.alias("filter_non_microcap_pass"),
        passes_all.alias("passes_all_filters"),
        status,
    )


def _require_columns(lf: pl.LazyFrame, required: tuple[str, ...], label: str) -> None:
    """Fail fast when an input frame is missing required columns."""
    schema = lf.collect_schema()
    missing = [name for name in required if name not in schema]
    if missing:
        raise ValueError(f"{label} missing required columns: {missing}")


def _project_columns_with_defaults(
    lf: pl.LazyFrame,
    *,
    required: tuple[str, ...],
    optional_defaults: tuple[tuple[str, pl.DataType, object | None], ...],
    label: str,
    ordered_columns: tuple[str, ...] | None = None,
) -> pl.LazyFrame:
    """Project a stable output schema while filling missing optional columns."""
    schema = lf.collect_schema()
    missing = [name for name in required if name not in schema]
    if missing:
        raise ValueError(f"{label} missing required columns: {missing}")

    default_map = {name: (dtype, default_value) for name, dtype, default_value in optional_defaults}
    ordered = ordered_columns or tuple(required) + tuple(default_map)

    exprs: list[pl.Expr] = []
    for name in ordered:
        if name in schema:
            if name in default_map:
                exprs.append(pl.col(name).cast(default_map[name][0], strict=False).alias(name))
            else:
                exprs.append(pl.col(name))
        else:
            dtype, default_value = default_map[name]
            exprs.append(pl.lit(default_value, dtype=dtype).alias(name))
    return lf.select(exprs)


def project_ccm_daily_market_core(daily_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Project the lean daily market-core artifact contract."""
    required = tuple(
        name
        for name in CCM_DAILY_MARKET_CORE_COLUMNS
        if name not in {"BID", "ASK", "NUMTRD", "OPENPRC", "SHROUT"}
    )
    return _project_columns_with_defaults(
        daily_lf,
        required=required,
        optional_defaults=(
            ("BID", pl.Float64, None),
            ("ASK", pl.Float64, None),
            ("NUMTRD", pl.Int64, None),
            ("OPENPRC", pl.Float64, None),
            ("SHROUT", pl.Float64, None),
        ),
        label="ccm daily market core",
        ordered_columns=CCM_DAILY_MARKET_CORE_COLUMNS,
    )


def project_ccm_daily_phase_b_surface(daily_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Project the canonical SEC-CCM Phase-B daily join surface."""
    _require_columns(daily_lf, CCM_DAILY_PHASE_B_SURFACE_COLUMNS, "ccm daily phase-b surface")
    return daily_lf.select(CCM_DAILY_PHASE_B_SURFACE_COLUMNS)


def project_ccm_daily_bridge_surface(daily_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Project the compact daily identifier surface for Refinitiv step 1."""
    return _project_columns_with_defaults(
        daily_lf,
        required=CCM_DAILY_BRIDGE_SURFACE_REQUIRED_COLUMNS,
        optional_defaults=(
            ("LINKTYPE", pl.Utf8, None),
            ("LINKPRIM", pl.Utf8, None),
            ("link_quality_flag", pl.Utf8, None),
            ("HEXCNTRY", pl.Utf8, None),
            ("n_filings", pl.Int64, 0),
        ),
        label="ccm daily bridge surface",
    )

def build_price_panel(
    sfz_ds: pl.LazyFrame,
    sfz_dp: pl.LazyFrame,
    sfz_del: pl.LazyFrame,
    sfz_nam: pl.LazyFrame,
    sfz_hdr: pl.LazyFrame,
    start_date: dt.date | dt.datetime | str,
    sfz_shr: pl.LazyFrame | None = None,
) -> pl.LazyFrame:
    """Merge CRSP price feeds plus delist data."""
    _require_columns(
        sfz_ds,
        ("KYPERMNO", "CALDT", "BIDLO", "ASKHI"),
        "sfz_ds_dly",
    )
    _require_columns(
        sfz_dp,
        ("KYPERMNO", "CALDT", "PRC", "RET", "RETX", "TCAP", "VOL"),
        "sfz_dp_dly",
    )
    _require_columns(
        sfz_del,
        ("KYPERMNO", "DLSTDT", "DLSTCD", "DLPRC", "DLAMT", "DLRET", "DLRETX"),
        "sfz_del",
    )
    _require_columns(
        sfz_nam,
        ("KYPERMNO", "NAMEDT", "NAMEENDDT", "TICKER", "SHRCD", "EXCHCD", "PRIMEXCH", "TRDSTAT", "SECSTAT"),
        "sfz_nam",
    )
    _require_columns(
        sfz_hdr,
        ("KYPERMNO", "BEGDT", "ENDDT", "HSHRCD", "HEXCD", "HPRIMEXCH", "HTRDSTAT", "HSECSTAT"),
        "sfz_hdr",
    )
    if sfz_shr is not None:
        _require_columns(
            sfz_shr,
            ("KYPERMNO", "SHRSDT", "SHRSENDDT", "SHROUT"),
            "sfz_shr",
        )

    start_dt = _coerce_date(start_date)
    ds = sfz_ds.filter(pl.col("CALDT") >= pl.lit(start_dt))
    dp = sfz_dp.filter(pl.col("CALDT") >= pl.lit(start_dt))

    price = dp.join(ds, on=["KYPERMNO", "CALDT"], how="full", coalesce=True).with_columns(
        _update_data_status(
            pl.lit(int(DataStatus.NONE), dtype=STATUS_DTYPE),
            conditional_flags=(
                (pl.col("RET").is_not_null(), DataStatus.HAS_RET),
                (pl.col("BIDLO").is_not_null(), DataStatus.HAS_BIDLO),
            ),
        ).alias("data_status")
    )

    nam_ticker = pl.col("TICKER").cast(pl.Utf8, strict=False).str.strip_chars()

    nam = (
        sfz_nam.select(
            pl.col("KYPERMNO").cast(pl.Int32, strict=False).alias("KYPERMNO"),
            pl.col("NAMEDT").cast(pl.Date, strict=False).alias("NAMEDT"),
            pl.col("NAMEENDDT").cast(pl.Date, strict=False).alias("NAMEENDDT"),
            pl.when(nam_ticker.str.len_chars().fill_null(0) > 0)
            .then(nam_ticker)
            .otherwise(pl.lit(None, dtype=pl.Utf8))
            .alias("_NAM_TICKER"),
            pl.col("SHRCD").cast(pl.Int32, strict=False).alias("_NAM_SHRCD"),
            pl.col("EXCHCD").cast(pl.Int32, strict=False).alias("_NAM_EXCHCD"),
            pl.col("PRIMEXCH").cast(pl.Utf8, strict=False).alias("_NAM_PRIMEXCH"),
            pl.col("TRDSTAT").cast(pl.Utf8, strict=False).alias("_NAM_TRDSTAT"),
            pl.col("SECSTAT").cast(pl.Utf8, strict=False).alias("_NAM_SECSTAT"),
        )
        .drop_nulls(subset=["KYPERMNO", "NAMEDT"])
        .unique(subset=["KYPERMNO", "NAMEDT"], keep="first")
        .sort("KYPERMNO", "NAMEDT")
    )
    hdr = (
        sfz_hdr.select(
            pl.col("KYPERMNO").cast(pl.Int32, strict=False).alias("KYPERMNO"),
            pl.col("BEGDT").cast(pl.Date, strict=False).alias("BEGDT"),
            pl.col("ENDDT").cast(pl.Date, strict=False).alias("ENDDT"),
            pl.col("HSHRCD").cast(pl.Int32, strict=False).alias("_HDR_SHRCD"),
            pl.col("HEXCD").cast(pl.Int32, strict=False).alias("_HDR_EXCHCD"),
            pl.col("HPRIMEXCH").cast(pl.Utf8, strict=False).alias("_HDR_PRIMEXCH"),
            pl.col("HTRDSTAT").cast(pl.Utf8, strict=False).alias("_HDR_TRDSTAT"),
            pl.col("HSECSTAT").cast(pl.Utf8, strict=False).alias("_HDR_SECSTAT"),
        )
        .drop_nulls(subset=["KYPERMNO", "BEGDT"])
        .unique(subset=["KYPERMNO", "BEGDT"], keep="first")
        .sort("KYPERMNO", "BEGDT")
    )

    price = price.with_columns(
        pl.col("KYPERMNO").cast(pl.Int32, strict=False).alias("KYPERMNO"),
        pl.col("CALDT").cast(pl.Date, strict=False).alias("CALDT"),
    ).sort("KYPERMNO", "CALDT")

    if sfz_shr is not None:
        shr = (
            sfz_shr.select(
                pl.col("KYPERMNO").cast(pl.Int32, strict=False).alias("KYPERMNO"),
                pl.col("SHRSDT").cast(pl.Date, strict=False).alias("SHRSDT"),
                pl.col("SHRSENDDT").cast(pl.Date, strict=False).alias("SHRSENDDT"),
                pl.col("SHROUT").cast(pl.Float64, strict=False).alias("_SHROUT"),
            )
            .drop_nulls(subset=["KYPERMNO", "SHRSDT"])
            .unique(subset=["KYPERMNO", "SHRSDT"], keep="first")
            .sort("KYPERMNO", "SHRSDT")
        )
        shr_valid = pl.col("SHRSDT").is_not_null() & (
            pl.col("SHRSENDDT").is_null() | (pl.col("CALDT") <= pl.col("SHRSENDDT"))
        )
        price = (
            price.join_asof(
                shr,
                left_on="CALDT",
                right_on="SHRSDT",
                by="KYPERMNO",
                strategy="backward",
                check_sortedness=False,
            )
            .with_columns(
                pl.when(shr_valid)
                .then(pl.col("_SHROUT"))
                .otherwise(pl.lit(None, dtype=pl.Float64))
                .alias("SHROUT")
            )
            .drop("SHRSDT", "SHRSENDDT", "_SHROUT", strict=False)
            .sort("KYPERMNO", "CALDT")
        )

    price = (
        price.join_asof(
            nam,
            left_on="CALDT",
            right_on="NAMEDT",
            by="KYPERMNO",
            strategy="backward",
            check_sortedness=False,
        )
        .join_asof(
            hdr,
            left_on="CALDT",
            right_on="BEGDT",
            by="KYPERMNO",
            strategy="backward",
            check_sortedness=False,
        )
    )

    nam_valid = pl.col("NAMEDT").is_not_null() & (pl.col("CALDT") <= pl.col("NAMEENDDT"))
    hdr_valid = pl.col("BEGDT").is_not_null() & (pl.col("CALDT") <= pl.col("ENDDT"))
    price = price.with_columns(
        pl.when(nam_valid).then(pl.col("_NAM_TICKER")).otherwise(pl.lit(None, dtype=pl.Utf8)).alias("TICKER"),
        pl.coalesce(
            [
                pl.when(nam_valid).then(pl.col("_NAM_SHRCD")).otherwise(pl.lit(None, dtype=pl.Int32)),
                pl.when(hdr_valid).then(pl.col("_HDR_SHRCD")).otherwise(pl.lit(None, dtype=pl.Int32)),
            ]
        ).alias("SHRCD"),
        pl.coalesce(
            [
                pl.when(nam_valid).then(pl.col("_NAM_EXCHCD")).otherwise(pl.lit(None, dtype=pl.Int32)),
                pl.when(hdr_valid).then(pl.col("_HDR_EXCHCD")).otherwise(pl.lit(None, dtype=pl.Int32)),
            ]
        ).alias("EXCHCD"),
        pl.coalesce(
            [
                pl.when(nam_valid).then(pl.col("_NAM_PRIMEXCH")).otherwise(pl.lit(None, dtype=pl.Utf8)),
                pl.when(hdr_valid).then(pl.col("_HDR_PRIMEXCH")).otherwise(pl.lit(None, dtype=pl.Utf8)),
            ]
        ).alias("PRIMEXCH"),
        pl.coalesce(
            [
                pl.when(nam_valid).then(pl.col("_NAM_TRDSTAT")).otherwise(pl.lit(None, dtype=pl.Utf8)),
                pl.when(hdr_valid).then(pl.col("_HDR_TRDSTAT")).otherwise(pl.lit(None, dtype=pl.Utf8)),
            ]
        ).alias("TRDSTAT"),
        pl.coalesce(
            [
                pl.when(nam_valid).then(pl.col("_NAM_SECSTAT")).otherwise(pl.lit(None, dtype=pl.Utf8)),
                pl.when(hdr_valid).then(pl.col("_HDR_SECSTAT")).otherwise(pl.lit(None, dtype=pl.Utf8)),
            ]
        ).alias("SECSTAT"),
    ).drop(
        "NAMEDT",
        "NAMEENDDT",
        "BEGDT",
        "ENDDT",
        "_NAM_TICKER",
        "_NAM_SHRCD",
        "_NAM_EXCHCD",
        "_NAM_PRIMEXCH",
        "_NAM_TRDSTAT",
        "_NAM_SECSTAT",
        "_HDR_SHRCD",
        "_HDR_EXCHCD",
        "_HDR_PRIMEXCH",
        "_HDR_TRDSTAT",
        "_HDR_SECSTAT",
        strict=False,
    )

    last_trade = price.group_by("KYPERMNO").agg(pl.col("CALDT").max().alias("LAST_CALDT"))

    trading_days = (
        price.select(
            "KYPERMNO",
            pl.col("CALDT"),
            pl.col("CALDT").alias("CALDT_CHECK"),
        )
        .unique()
    )

    delist_info = sfz_del.join(last_trade, on="KYPERMNO", how="inner")

    delist_check = delist_info.join(
        trading_days.select("KYPERMNO", "CALDT", "CALDT_CHECK"),
        left_on=["KYPERMNO", "DLSTDT"],
        right_on=["KYPERMNO", "CALDT"],
        how="left",
    )

    delist_payload = (
        delist_check.with_columns(
            pl.col("CALDT_CHECK").is_not_null().alias("dlst_is_trading_day"),
            pl.when(pl.col("CALDT_CHECK").is_not_null())
            .then(pl.col("DLSTDT"))
            .otherwise(pl.col("LAST_CALDT"))
            .alias("MATCH_DATE"),
        )
        .drop("CALDT", "CALDT_CHECK", strict=False)
    )

    delist_cols = ["KYPERMNO", "MATCH_DATE", "DLSTDT", "DLSTCD", "DLPRC", "DLAMT", "DLRET", "DLRETX"]
    delist_final = delist_payload.select(delist_cols).unique(subset=["KYPERMNO", "MATCH_DATE"], keep="first")

    panel = price.join(
        delist_final,
        left_on=["KYPERMNO", "CALDT"],
        right_on=["KYPERMNO", "MATCH_DATE"],
        how="left",
    )
    return apply_concept_filter_flags_doc(panel)


def add_final_returns(price_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Add FINAL_RET/RETX/PRC and provenance flags."""
    lf = _ensure_data_status(price_lf)

    ret_available = pl.col("RET").is_not_null()
    retx_available = pl.col("RETX").is_not_null()
    prc_available = pl.col("PRC").is_not_null()
    dlret_available = pl.col("DLRET").is_not_null()
    dlretx_available = pl.col("DLRETX").is_not_null()
    dlprc_available = pl.col("DLPRC").is_not_null()

    availability_flags = _update_data_status(
        pl.col("data_status"),
        conditional_flags=(
            (ret_available, DataStatus.HAS_RET),
            (retx_available, DataStatus.HAS_RETX),
            (prc_available, DataStatus.HAS_PRC),
            (dlret_available, DataStatus.HAS_DLRET),
            (dlretx_available, DataStatus.HAS_DLRETX),
            (dlprc_available, DataStatus.HAS_DLPRC),
        ),
    ).alias("data_status")

    return lf.with_columns(
        availability_flags,
        pl.when(ret_available & dlret_available)
        .then((1.0 + pl.col("RET")) * (1.0 + pl.col("DLRET")) - 1.0)
        .when(dlret_available)
        .then(pl.col("DLRET"))
        .otherwise(pl.col("RET"))
        .alias("FINAL_RET"),
        pl.when(retx_available & dlretx_available)
        .then((1.0 + pl.col("RETX")) * (1.0 + pl.col("DLRETX")) - 1.0)
        .when(dlretx_available)
        .then(pl.col("DLRETX"))
        .otherwise(pl.col("RETX"))
        .alias("FINAL_RETX"),
        pl.when(dlprc_available)
        .then(pl.col("DLPRC").abs())
        .otherwise(pl.col("PRC").abs())
        .alias("FINAL_PRC"),
    )


def attach_filings(price_lf: pl.LazyFrame, filings_lf: pl.LazyFrame, keep_forms: list[str]) -> pl.LazyFrame:
    """Map filings to the next trading day and align as arrays on the price panel."""
    normalized_keep_forms = [
        form
        for form in {_normalize_form_token_for_match(form) for form in keep_forms}
        if form is not None
    ]
    trading_calendar = (
        price_lf
        .with_columns(pl.col("CALDT").cast(pl.Date, strict=False).alias("TRADING_DATE"))
        .select("TRADING_DATE")
        .drop_nulls()
        .unique()
        .sort("TRADING_DATE")
    )

    tmin = trading_calendar.select(pl.col("TRADING_DATE").min().alias("tmin")).collect().item()

    filings = (
        filings_lf
        .with_columns(_normalize_form_for_match(pl.col("SRCTYPE")).alias("_SRCTYPE_MATCH"))
        .filter(pl.col("_SRCTYPE_MATCH").is_in(normalized_keep_forms))
        .with_columns([
            pl.col("LPERMNO").cast(pl.Int32),
            pl.col("FILEDATE").cast(pl.Date),
            pl.col("FILEDATETIME").str.strptime(pl.Time, format="%H:%M:%S", strict=False).alias("_FILETIME"),
        ])
        .with_columns([
            pl.when(pl.col("_FILETIME").is_not_null())
            .then(
                (pl.col("FILEDATE").cast(pl.Datetime) + pl.duration(
                    hours=pl.col("_FILETIME").dt.hour(),
                    minutes=pl.col("_FILETIME").dt.minute(),
                    seconds=pl.col("_FILETIME").dt.second(),
                )).dt.replace_time_zone("America/New_York")
            )
            .otherwise(pl.lit(None, dtype=pl.Datetime(time_zone="America/New_York")))
            .alias("FILEDATETIME_ET"),
        ])
        .drop("_SRCTYPE_MATCH")
        .select(["LPERMNO", "SRCTYPE", "FILEDATE", "FILEDATETIME_ET"])
        .filter(pl.col("FILEDATE") >= pl.lit(tmin))
    )

    event_map = (
        filings
        .with_columns(pl.col("FILEDATE").alias("CALDATE_KEY"))
        .sort("CALDATE_KEY")
        .join_asof(
            trading_calendar,
            left_on="CALDATE_KEY",
            right_on="TRADING_DATE",
            strategy="forward",
        )
        .rename({"TRADING_DATE": "EVENT_TDATE"})
        .select(["LPERMNO", "SRCTYPE", "FILEDATE", "FILEDATETIME_ET", "EVENT_TDATE"])
    )

    event_bag = (
        event_map
        .with_row_index("row_idx")
        .with_columns([
            pl.coalesce([
                pl.col("FILEDATETIME_ET"),
                pl.col("FILEDATE").cast(pl.Datetime).dt.replace_time_zone("America/New_York"),
            ]).alias("_sort_dt"),
            pl.struct(["SRCTYPE", "FILEDATE", "FILEDATETIME_ET"]).alias("_rec"),
        ])
        .group_by(["LPERMNO", "EVENT_TDATE"])
        .agg([
            pl.col("_rec").sort_by(["_sort_dt", "row_idx"]).alias("FILINGS"),
        ])
        .with_columns([
            pl.col("FILINGS").list.eval(pl.element().struct.field("SRCTYPE")).alias("SRCTYPE_all"),
            pl.col("FILINGS").list.eval(pl.element().struct.field("FILEDATE")).alias("FILEDATE_all"),
            pl.col("FILINGS").list.eval(pl.element().struct.field("FILEDATETIME_ET")).alias("FILEDATETIME_all"),
            pl.col("FILINGS").list.len().alias("n_filings"),
        ])
        .select(["LPERMNO", "EVENT_TDATE", "SRCTYPE_all", "FILEDATE_all", "FILEDATETIME_all", "n_filings"])
    )

    return (
        price_lf
        .with_columns([
            pl.col("KYPERMNO").cast(pl.Int32),
            pl.col("CALDT").cast(pl.Date, strict=False).alias("CALDT"),
        ])
        .join(
            event_bag,
            left_on=["KYPERMNO", "CALDT"],
            right_on=["LPERMNO", "EVENT_TDATE"],
            how="left",
        )
    )


def attach_ccm_links(price_filings_lf: pl.LazyFrame, link_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Select best CCM link per permno/date from canonical time-sliced rows."""
    base = price_filings_lf.with_columns(
        pl.col("KYPERMNO").cast(pl.Int32, strict=False),
        pl.col("CALDT").cast(pl.Date, strict=False),
    )
    links = normalize_canonical_link_table(link_lf, strict=True).select(
        "gvkey",
        "kypermno",
        "liid",
        "link_start",
        "link_end",
        "valid_start",
        "valid_end",
        "linktype",
        "linkprim",
        "link_rank_effective",
        "link_quality",
        "source_priority",
        "row_quality_tier",
        "has_window",
        "is_sparse_fallback",
    ).rename({"kypermno": "KYPERMNO"})

    date_valid_expr = (
        (pl.col("valid_start").is_null() | (pl.col("CALDT") >= pl.col("valid_start")))
        & (pl.col("valid_end").is_null() | (pl.col("CALDT") <= pl.col("valid_end")))
    )
    candidate_base = (
        base.select("KYPERMNO", "CALDT")
        .join(links, on="KYPERMNO", how="left")
        .drop_nulls(subset=["gvkey", "KYPERMNO"])
        .with_columns(
            date_valid_expr.alias("_date_valid"),
            (pl.col("KYPERMNO") > pl.lit(0)).alias("_permno_positive"),
        )
        .filter(pl.col("_date_valid"))
        .with_columns(
            (
                pl.col("_permno_positive")
                & pl.col("has_window")
                & pl.col("is_sparse_fallback").not_()
            ).alias("_is_stage1"),
            (
                pl.col("_permno_positive")
                & pl.col("is_sparse_fallback")
            ).alias("_is_stage2"),
        )
    )
    stage_presence = candidate_base.group_by(["KYPERMNO", "CALDT"]).agg(
        pl.col("_is_stage1").any().alias("_has_stage1")
    )
    eligible = (
        candidate_base
        .join(stage_presence, on=["KYPERMNO", "CALDT"], how="left")
        .filter(pl.col("_is_stage1") | (pl.col("_has_stage1").not_() & pl.col("_is_stage2")))
    )
    selected = (
        eligible.with_columns(
            pl.col("valid_start").fill_null(dt.date(1, 1, 1)).alias("_sort_valid_start"),
            pl.col("valid_end").fill_null(dt.date(9999, 12, 31)).alias("_sort_valid_end"),
            pl.col("liid").fill_null("").alias("_sort_liid"),
        )
        .sort(
            [
                "KYPERMNO",
                "CALDT",
                "row_quality_tier",
                "source_priority",
                "link_rank_effective",
                "link_quality",
                "_sort_valid_start",
                "_sort_valid_end",
                "gvkey",
                "KYPERMNO",
                "_sort_liid",
            ],
            descending=[False, False, False, False, False, True, True, False, False, False, False],
        )
        .group_by(["KYPERMNO", "CALDT"], maintain_order=True)
        .agg(
            pl.first("gvkey").alias("_sel_gvkey"),
            pl.first("liid").alias("_sel_liid"),
            pl.first("link_start").alias("_sel_link_start"),
            pl.first("link_end").alias("_sel_link_end"),
            pl.first("linktype").alias("_sel_linktype"),
            pl.first("linkprim").alias("_sel_linkprim"),
            pl.first("link_rank_effective").cast(pl.Int32).alias("_sel_link_rank"),
        )
    )

    selected_joined = base.join(selected, on=["KYPERMNO", "CALDT"], how="left").with_columns(
        pl.col("_sel_gvkey").is_not_null().alias("valid_link"),
        pl.col("_sel_linktype").cast(pl.Utf8, strict=False).str.to_uppercase().alias("_sel_linktype_upper"),
        pl.col("_sel_linkprim").cast(pl.Utf8, strict=False).str.to_uppercase().alias("_sel_linkprim_upper"),
        (
            pl.col("_sel_linktype").cast(pl.Utf8, strict=False).str.to_uppercase().is_in(["LC", "LU"])
            & pl.col("_sel_linkprim").cast(pl.Utf8, strict=False).str.to_uppercase().is_in(["P", "C"])
        ).fill_null(False).alias("is_canonical_link"),
    )

    link_rank_base = (
        pl.when(
            pl.col("is_canonical_link")
            & (pl.col("_sel_linktype_upper") == pl.lit("LC"))
            & (pl.col("_sel_linkprim_upper") == pl.lit("P"))
        )
        .then(pl.lit(1, dtype=pl.Int32))
        .when(pl.col("is_canonical_link") & (pl.col("_sel_linkprim_upper") == pl.lit("P")))
        .then(pl.lit(2, dtype=pl.Int32))
        .when(pl.col("is_canonical_link"))
        .then(pl.lit(3, dtype=pl.Int32))
        .otherwise(pl.lit(4, dtype=pl.Int32))
    )

    masked = selected_joined.with_columns(
        pl.when(pl.col("valid_link")).then(pl.col("_sel_gvkey")).otherwise(pl.lit(None, dtype=pl.Utf8)).alias("KYGVKEY_ccm"),
        pl.when(pl.col("valid_link")).then(pl.col("_sel_liid")).otherwise(pl.lit(None, dtype=pl.Utf8)).alias("LIID"),
        pl.when(pl.col("valid_link")).then(pl.col("_sel_link_start")).otherwise(pl.lit(None, dtype=pl.Date)).alias("LINKDT"),
        pl.when(pl.col("valid_link")).then(pl.col("_sel_link_end")).otherwise(pl.lit(None, dtype=pl.Date)).alias("LINKENDDT"),
        pl.when(pl.col("valid_link")).then(pl.col("_sel_linktype_upper")).otherwise(pl.lit(None, dtype=pl.Utf8)).alias("LINKTYPE"),
        pl.when(pl.col("valid_link")).then(pl.col("_sel_linkprim_upper")).otherwise(pl.lit(None, dtype=pl.Utf8)).alias("LINKPRIM"),
        pl.when(pl.col("valid_link")).then(pl.col("is_canonical_link")).otherwise(pl.lit(None, dtype=pl.Boolean)).alias("is_canonical_link"),
        link_rank_base.alias("link_rank_base"),
        pl.when(pl.col("valid_link"))
        .then(pl.col("_sel_link_rank"))
        .otherwise(pl.lit(9, dtype=pl.Int32))
        .alias("link_rank"),
    )

    return masked.with_columns(
        pl.col("KYGVKEY_ccm").alias("KYGVKEY_final"),
        pl.when(pl.col("KYGVKEY_ccm").is_null())
        .then(pl.lit("no_ccm_link"))
        .when(pl.col("is_canonical_link").fill_null(False) & (pl.col("LINKTYPE") == "LC") & (pl.col("LINKPRIM") == "P"))
        .then(pl.lit("canonical_primary_LC"))
        .when(pl.col("is_canonical_link").fill_null(False) & (pl.col("LINKPRIM") == "P"))
        .then(pl.lit("canonical_primary_other"))
        .when(pl.col("is_canonical_link").fill_null(False))
        .then(pl.lit("canonical_other"))
        .otherwise(pl.lit("noncanonical"))
        .alias("link_quality_flag"),
    ).drop(
        "_sel_gvkey",
        "_sel_liid",
        "_sel_link_start",
        "_sel_link_end",
        "_sel_linktype",
        "_sel_linktype_upper",
        "_sel_linkprim",
        "_sel_linkprim_upper",
        "_sel_link_rank",
        strict=False,
    )


def attach_company_description(
    flagged_lf: pl.LazyFrame,
    comp_desc_lf: pl.LazyFrame,
    desc_key_col: str = "KYGVKEY",
    desc_cik_col: str = "CIK",
) -> pl.LazyFrame:
    """
    Attach description availability and harmonized CIK from the company description feed.

    Expects that KYGVKEY_final already exists (e.g., after CCM linking).
    Prefers HCIK (from company history) over existing CIK_final over description-derived CIK.
    """
    lf = _ensure_data_status(flagged_lf)

    schema = lf.collect_schema()
    gvkey_dtype = schema.get("KYGVKEY_final", pl.Utf8)

    # --- 1) Existence flag map (keep a marker column; do NOT depend on join key surviving) ---
    desc_keys = (
        comp_desc_lf
        .select([
            pl.col(desc_key_col).cast(gvkey_dtype, strict=False).alias("KYGVKEY_final"),
            pl.lit(True).alias("_has_comp_desc"),
        ])
        .drop_nulls(subset=["KYGVKEY_final"])
        .unique(subset=["KYGVKEY_final"])
    )

    # --- 2) Deterministic-ish CIK map (mode per GVKEY) ---
    cik_map = (
        comp_desc_lf
        .select([
            pl.col(desc_key_col).cast(gvkey_dtype, strict=False).alias("KYGVKEY_final"),
            pl.col(desc_cik_col).cast(pl.Utf8, strict=False).alias("CIK_raw"),
        ])
        .drop_nulls(subset=["KYGVKEY_final"])
        .with_columns(
            pl.col("CIK_raw")
              .str.strip_chars()
              .str.replace_all(r"\.0$", "")
              .str.replace_all(r"\D", "")
              .alias("CIK_digits")
        )
        .with_columns(
            pl.when(pl.col("CIK_digits").str.len_chars() > 0)
              .then(pl.col("CIK_digits").str.zfill(10))
              .otherwise(None)
              .alias("CIK_desc_10")
        )
        .group_by("KYGVKEY_final")
        .agg([
            pl.col("CIK_desc_10").drop_nulls().mode().first().alias("CIK_desc_10"),
            pl.col("CIK_desc_10").drop_nulls().n_unique().alias("n_cik_desc_uniq"),
        ])
    )

    out = (
        lf
        .join(desc_keys, on="KYGVKEY_final", how="left")
        .with_columns(
            _update_data_status(
                pl.col("data_status"),
                conditional_flags=((pl.col("_has_comp_desc").fill_null(False), DataStatus.HAS_COMP_DESC),),
            ).alias("data_status")
        )
        .drop("_has_comp_desc", strict=False)
        .join(cik_map, on="KYGVKEY_final", how="left")
    )

    # Normalize CompHist CIK too (avoid turning empty-string into "0000000000")
    if "HCIK" in schema:
        out = out.with_columns(
            pl.col("HCIK").cast(pl.Utf8, strict=False)
              .str.strip_chars()
              .str.replace_all(r"\.0$", "")
              .str.replace_all(r"\D", "")
              .alias("_HCIK_digits")
        ).with_columns(
            pl.when(pl.col("_HCIK_digits").str.len_chars() > 0)
              .then(pl.col("_HCIK_digits").str.zfill(10))
              .otherwise(None)
              .alias("HCIK_10")
        ).drop("_HCIK_digits", strict=False)
    else:
        out = out.with_columns(pl.lit(None, dtype=pl.Utf8).alias("HCIK_10"))

    existing_cik_final = pl.col("CIK_final") if "CIK_final" in schema else pl.lit(None, dtype=pl.Utf8)

    return out.with_columns(
        pl.coalesce([pl.col("HCIK_10"), existing_cik_final, pl.col("CIK_desc_10")]).alias("CIK_final")
    )
