"""SEC<->CCM pre-merge logic for Phase A linking and Phase B date alignment.

The module exposes doc-grain functions used by the SEC-CCM pipeline:
- normalize filings and enforce required keys,
- resolve canonical links with staged candidate rules,
- align filings to trading dates and optional daily rows,
- assign stable reason codes and unmatched diagnostics outputs.
"""

from __future__ import annotations

import datetime as dt

import polars as pl

from thesis_pkg.core.ccm.canonical_links import normalize_canonical_link_table
from thesis_pkg.core.ccm.sec_ccm_contracts import (
    MatchReasonCode,
    PhaseBAlignmentMode,
    PhaseBDailyJoinMode,
    SecCcmJoinSpec,
    SecCcmJoinSpecV1,
    SecCcmJoinSpecV2,
    normalize_sec_ccm_join_spec,
)
from thesis_pkg.core.ccm.transforms import DataStatus, STATUS_DTYPE, _ensure_data_status, _update_data_status


def _require_columns(lf: pl.LazyFrame, required: tuple[str, ...], label: str) -> None:
    """Raise when required input columns are missing."""
    schema = lf.collect_schema()
    missing = [name for name in required if name not in schema]
    if missing:
        raise ValueError(f"{label} missing required columns: {missing}")


def _resolve_first_existing(schema: pl.Schema, candidates: tuple[str, ...], label: str) -> str:
    """Return first existing name from a set of accepted aliases."""
    for candidate in candidates:
        if candidate in schema:
            return candidate
    raise ValueError(f"{label} missing any of expected columns: {list(candidates)}")


def _normalized_cik10_expr(col_name: str) -> pl.Expr:
    """Normalize a CIK-like column to a 10-digit zero-padded string."""
    digits = (
        pl.col(col_name)
        .cast(pl.Utf8, strict=False)
        .str.strip_chars()
        .str.replace_all(r"\D", "")
    )
    return (
        pl.when(digits.str.len_chars() > 0)
        .then(digits.str.zfill(10))
        .otherwise(None)
        .alias(col_name)
    )


def _normalize_link_universe(link_universe_lf: pl.LazyFrame, *, strict: bool = True) -> pl.LazyFrame:
    """Validate/cast canonical link-universe input for Phase A/diagnostics."""
    return normalize_canonical_link_table(link_universe_lf, strict=strict)


def _requested_alignment_policy_value(join_spec: SecCcmJoinSpec) -> str:
    """Extract the caller-requested policy label for traceability."""
    if isinstance(join_spec, SecCcmJoinSpecV1):
        return join_spec.alignment_policy
    return join_spec.phase_b_alignment_mode.value


def _normalize_daily_join_input(daily_lf: pl.LazyFrame, join_spec: SecCcmJoinSpecV2) -> pl.LazyFrame:
    """Normalize daily panel keys/features to canonical Phase-B join columns."""
    schema = daily_lf.collect_schema()
    perm_col = _resolve_first_existing(
        schema,
        (join_spec.daily_permno_col, join_spec.daily_permno_col.lower(), "KYPERMNO", "LPERMNO", "PERMNO"),
        "daily join input",
    )
    date_col = _resolve_first_existing(
        schema,
        (join_spec.daily_date_col, join_spec.daily_date_col.lower(), "CALDT", "caldt"),
        "daily join input",
    )

    required_missing = [col for col in join_spec.required_daily_non_null_features if col not in schema]
    if required_missing:
        raise ValueError(f"Daily join input missing required non-null feature columns: {required_missing}")
    selected_features: list[str] = []
    seen_features: set[str] = set()
    for col in (*join_spec.daily_feature_columns, *join_spec.required_daily_non_null_features):
        if col in schema and col not in seen_features:
            selected_features.append(col)
            seen_features.add(col)

    return (
        daily_lf.select(
            pl.col(perm_col).cast(pl.Int32, strict=False).alias("kypermno"),
            pl.col(date_col).cast(pl.Date, strict=False).alias("daily_caldt"),
            *[pl.col(col) for col in selected_features],
        )
        .drop_nulls(subset=["kypermno", "daily_caldt"])
        .unique(subset=["kypermno", "daily_caldt"], keep="first")
    )


def normalize_sec_filings_phase_a(sec_filings_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Normalize SEC filing fields required for Phase A linking.

    Args:
        sec_filings_lf: Input filings at doc grain.

    Returns:
        pl.LazyFrame: Filings with normalized ``doc_id``, ``cik_10``, ``filing_date``,
        optional ``acceptance_datetime``, boolean ``has_acceptance_datetime``,
        and non-null ``data_status``.

    Raises:
        ValueError: If required columns ``doc_id``, ``cik_10``, or ``filing_date`` are missing.
    """
    _require_columns(sec_filings_lf, ("doc_id", "cik_10", "filing_date"), "sec_filings")
    schema = sec_filings_lf.collect_schema()
    acceptance_col_present = "acceptance_datetime" in schema

    normalized = _ensure_data_status(sec_filings_lf).with_columns(
        pl.col("doc_id").cast(pl.Utf8, strict=False),
        _normalized_cik10_expr("cik_10"),
        pl.col("filing_date").cast(pl.Date, strict=False),
        (
            pl.col("acceptance_datetime").cast(pl.Datetime, strict=False)
            if acceptance_col_present
            else pl.lit(None, dtype=pl.Datetime).alias("acceptance_datetime")
        ),
    )

    return normalized.with_columns(
        pl.col("acceptance_datetime").is_not_null().alias("has_acceptance_datetime"),
        pl.col("data_status").cast(STATUS_DTYPE).fill_null(int(DataStatus.NONE)),
    )


def resolve_links_phase_a(sec_norm_lf: pl.LazyFrame, link_universe_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Resolve each filing to a single ``gvkey``/``kypermno`` candidate for Phase A.

    Candidate selection is conservative and date-valid:
    1) filter to rows valid on ``filing_date``;
    2) prefer Stage-1 rows (positive permno, non-sparse, has link window),
       otherwise Stage-2 sparse fallback rows;
    3) order by ``row_quality_tier``, ``source_priority``,
       ``link_rank_effective``, and ``link_quality`` with deterministic
       suffix ordering.
    If multiple distinct IDs share the top rank tuple, the filing is marked
    ambiguous.

    Args:
        sec_norm_lf: SEC filings input (doc grain).
        link_universe_lf: CCM link universe.

    Returns:
        pl.LazyFrame: Phase A output containing reason codes, selected link identifiers,
        link-candidate diagnostics, and updated ``data_status`` flags.

    Raises:
        ValueError: If required SEC or link-universe columns are missing.
    """
    sec_base = normalize_sec_filings_phase_a(sec_norm_lf).with_columns(
        (
            pl.col("doc_id").is_not_null()
            & pl.col("cik_10").str.contains(r"^\d{10}$").fill_null(False)
            & pl.col("filing_date").is_not_null()
        ).alias("_valid_input")
    )
    links = _normalize_link_universe(link_universe_lf, strict=True)
    cik_link_stats = links.group_by("cik_10").agg(
        pl.len().gt(0).alias("_cik_has_any_link_row"),
        (pl.col("kypermno") > pl.lit(0)).any().alias("_cik_has_any_positive_permno"),
    )

    date_valid_expr = (
        (pl.col("valid_start").is_null() | (pl.col("filing_date") >= pl.col("valid_start")))
        & (pl.col("valid_end").is_null() | (pl.col("filing_date") <= pl.col("valid_end")))
    )

    candidate_base = (
        sec_base.filter(pl.col("_valid_input"))
        .select("doc_id", "cik_10", "filing_date")
        .join(links, on="cik_10", how="left")
        .drop_nulls(subset=["gvkey", "kypermno"])
        .with_columns(
            date_valid_expr.alias("_date_valid"),
            (pl.col("kypermno") > pl.lit(0)).alias("_permno_positive"),
        )
        .filter(pl.col("_date_valid"))
        .with_columns(
            (
                pl.col("_permno_positive")
                & pl.col("has_window")
                & pl.col("is_sparse_fallback").not_()
            ).alias("_is_stage1"),
            (
                pl.col("_permno_positive")
                & pl.col("is_sparse_fallback")
            ).alias("_is_stage2"),
        )
    )
    date_valid_positive_stats = candidate_base.group_by("doc_id").agg(
        pl.col("_permno_positive").any().alias("_has_any_date_valid_positive_row")
    )

    stage_presence = candidate_base.group_by("doc_id").agg(
        pl.col("_is_stage1").any().alias("_has_stage1")
    )
    eligible_candidates = (
        candidate_base
        .join(stage_presence, on="doc_id", how="left")
        .filter(pl.col("_is_stage1") | (pl.col("_has_stage1").not_() & pl.col("_is_stage2")))
    )

    candidate_counts = eligible_candidates.group_by("doc_id").agg(
        pl.len().cast(pl.Int32).alias("link_candidate_count")
    )

    best_tier = eligible_candidates.group_by("doc_id").agg(
        pl.col("row_quality_tier").min().alias("_best_row_quality_tier")
    )
    top_tier = eligible_candidates.join(best_tier, on="doc_id", how="inner").filter(
        pl.col("row_quality_tier") == pl.col("_best_row_quality_tier")
    )

    best_source = top_tier.group_by("doc_id").agg(
        pl.col("source_priority").min().alias("_best_source_priority")
    )
    top_source = top_tier.join(best_source, on="doc_id", how="inner").filter(
        pl.col("source_priority") == pl.col("_best_source_priority")
    )

    best_rank = top_source.group_by("doc_id").agg(
        pl.col("link_rank_effective").min().alias("_best_link_rank_effective")
    )
    top_rank = top_source.join(best_rank, on="doc_id", how="inner").filter(
        pl.col("link_rank_effective") == pl.col("_best_link_rank_effective")
    )

    best_quality = top_rank.group_by("doc_id").agg(
        pl.col("link_quality").max().alias("_best_link_quality")
    )
    top_candidates = top_rank.join(best_quality, on="doc_id", how="inner").filter(
        pl.col("link_quality") == pl.col("_best_link_quality")
    )

    tie_stats = top_candidates.group_by("doc_id").agg(
        pl.len().cast(pl.Int32).alias("top_rank_tie_count"),
        pl.struct(["gvkey", "kypermno"]).n_unique().cast(pl.Int32).alias("_top_distinct_id_count"),
    )

    top_choice = (
        top_candidates.with_columns(
            pl.col("valid_start").fill_null(dt.date(1, 1, 1)).alias("_sort_valid_start"),
            pl.col("valid_end").fill_null(dt.date(9999, 12, 31)).alias("_sort_valid_end"),
            pl.col("liid").fill_null("").alias("_sort_liid"),
        )
        .sort(
            [
                "doc_id",
                "row_quality_tier",
                "source_priority",
                "link_rank_effective",
                "link_quality",
                "_sort_valid_start",
                "_sort_valid_end",
                "gvkey",
                "kypermno",
                "_sort_liid",
            ],
            descending=[False, False, False, False, True, True, False, False, False, False],
        )
        .group_by("doc_id", maintain_order=True)
        .agg(
            pl.first("gvkey").alias("_top_gvkey"),
            pl.first("kypermno").cast(pl.Int32).alias("_top_kypermno"),
            pl.first("link_quality").cast(pl.Float64).alias("_top_link_quality"),
        )
    )

    enriched = (
        sec_base
        .join(cik_link_stats, on="cik_10", how="left")
        .join(date_valid_positive_stats, on="doc_id", how="left")
        .join(candidate_counts, on="doc_id", how="left")
        .join(tie_stats, on="doc_id", how="left")
        .join(top_choice, on="doc_id", how="left")
        .with_columns(
            pl.col("_cik_has_any_link_row").fill_null(False),
            pl.col("_cik_has_any_positive_permno").fill_null(False),
            pl.col("_has_any_date_valid_positive_row").fill_null(False),
            pl.col("link_candidate_count").fill_null(0).cast(pl.Int32),
            pl.col("top_rank_tie_count").fill_null(0).cast(pl.Int32),
            pl.col("_top_distinct_id_count").fill_null(0).cast(pl.Int32),
            (pl.col("link_candidate_count").fill_null(0).cast(pl.Int32) > pl.lit(0)).alias("_has_any_eligible_candidate"),
        )
    )

    phase_a_reason = (
        pl.when(pl.col("_valid_input").not_())
        .then(pl.lit(MatchReasonCode.BAD_INPUT.value))
        .when(pl.col("_cik_has_any_link_row").not_())
        .then(pl.lit(MatchReasonCode.CIK_NOT_IN_LINK_UNIVERSE.value))
        .when(pl.col("_cik_has_any_positive_permno").not_())
        .then(pl.lit(MatchReasonCode.CIK_PRESENT_NO_POSITIVE_LINK.value))
        .when(pl.col("_has_any_date_valid_positive_row").not_())
        .then(pl.lit(MatchReasonCode.NO_DATE_VALID_POSITIVE_LINK.value))
        .when(pl.col("_has_any_eligible_candidate").not_())
        .then(pl.lit(MatchReasonCode.NO_ELIGIBLE_LINK_CANDIDATE.value))
        .when((pl.col("top_rank_tie_count") > 1) & (pl.col("_top_distinct_id_count") > 1))
        .then(pl.lit(MatchReasonCode.AMBIGUOUS_LINK.value))
        .otherwise(pl.lit(MatchReasonCode.OK.value))
    )

    out = enriched.with_columns(
        phase_a_reason.alias("phase_a_reason_code"),
        phase_a_reason.alias("match_reason_code"),
        pl.when(phase_a_reason == pl.lit(MatchReasonCode.OK.value))
        .then(pl.col("_top_gvkey"))
        .otherwise(pl.lit(None, dtype=pl.Utf8))
        .alias("gvkey"),
        pl.when(phase_a_reason == pl.lit(MatchReasonCode.OK.value))
        .then(pl.col("_top_kypermno"))
        .otherwise(pl.lit(None, dtype=pl.Int32))
        .alias("kypermno"),
        pl.when(phase_a_reason == pl.lit(MatchReasonCode.OK.value))
        .then(pl.col("_top_link_quality"))
        .otherwise(pl.lit(None, dtype=pl.Float64))
        .alias("link_quality"),
    )

    status = _update_data_status(
        pl.col("data_status"),
        static_flags=DataStatus.SEC_CCM_PHASE_A_ATTEMPTED,
        conditional_flags=(
            (pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.BAD_INPUT.value), DataStatus.SEC_CCM_BAD_INPUT),
            (
                pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.CIK_NOT_IN_LINK_UNIVERSE.value),
                DataStatus.SEC_CCM_CIK_NOT_IN_LINK_UNIVERSE,
            ),
            (
                pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.CIK_PRESENT_NO_POSITIVE_LINK.value),
                DataStatus.SEC_CCM_CIK_PRESENT_NO_POSITIVE_LINK,
            ),
            (
                pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.NO_DATE_VALID_POSITIVE_LINK.value),
                DataStatus.SEC_CCM_NO_DATE_VALID_POSITIVE_LINK,
            ),
            (
                pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.NO_ELIGIBLE_LINK_CANDIDATE.value),
                DataStatus.SEC_CCM_NO_ELIGIBLE_LINK_CANDIDATE,
            ),
            (
                pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.AMBIGUOUS_LINK.value),
                DataStatus.SEC_CCM_AMBIGUOUS_LINK,
            ),
            (pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.OK.value), DataStatus.SEC_CCM_LINKED_OK),
            (pl.col("has_acceptance_datetime"), DataStatus.SEC_CCM_HAS_ACCEPTANCE_DATETIME),
        ),
    ).alias("data_status")

    return out.with_columns(status).drop(
        "_valid_input",
        "_top_distinct_id_count",
        "_top_gvkey",
        "_top_kypermno",
        "_top_link_quality",
        "_cik_has_any_link_row",
        "_cik_has_any_positive_permno",
        "_has_any_date_valid_positive_row",
        "_has_any_eligible_candidate",
        strict=False,
    )


def align_doc_dates_phase_b(
    links_doc_lf: pl.LazyFrame,
    trading_calendar_lf: pl.LazyFrame,
    join_spec: SecCcmJoinSpec,
) -> pl.LazyFrame:
    """Compute Phase B document-date alignment at doc grain.

    Alignment policy is controlled by ``join_spec``. The function adds
    ``aligned_caldt`` and ``alignment_lag_days`` and records effective/requested
    alignment policy labels.

    Args:
        links_doc_lf: Phase A link output.
        trading_calendar_lf: Trading calendar input.
        join_spec: Phase B alignment/join configuration.

    Returns:
        pl.LazyFrame: Input rows with alignment columns and updated ``data_status``
        flags for alignment attempted/aligned outcomes.

    Raises:
        ValueError: If required columns are missing from ``links_doc_lf`` or
            ``trading_calendar_lf``.
        TypeError: If ``join_spec`` is an unsupported type.
    """
    join_spec_v2 = normalize_sec_ccm_join_spec(join_spec)
    alignment_mode = join_spec_v2.phase_b_alignment_mode
    requested_alignment_policy = _requested_alignment_policy_value(join_spec)
    _require_columns(
        links_doc_lf,
        ("doc_id", "filing_date", "kypermno", "phase_a_reason_code", "data_status"),
        "phase A links",
    )

    trading_schema = trading_calendar_lf.collect_schema()
    date_col = _resolve_first_existing(
        trading_schema,
        (
            join_spec_v2.daily_date_col,
            join_spec_v2.daily_date_col.lower(),
            "CALDT",
            "caldt",
            "TRADING_DATE",
        ),
        "trading calendar",
    )

    trading_calendar = (
        trading_calendar_lf.select(pl.col(date_col).cast(pl.Date, strict=False).alias("_calendar_date"))
        .drop_nulls(subset=["_calendar_date"])
        .unique()
        .sort("_calendar_date")
    )

    if alignment_mode == PhaseBAlignmentMode.NEXT_TRADING_DAY_STRICT:
        alignment_anchor_expr = pl.when(pl.col("filing_date").is_not_null()).then(
            pl.col("filing_date") + pl.duration(days=1)
        )
    else:
        alignment_anchor_expr = pl.when(pl.col("filing_date").is_not_null()).then(pl.col("filing_date"))

    base = _ensure_data_status(links_doc_lf).with_columns(
        pl.col("filing_date").cast(pl.Date, strict=False),
        pl.col("kypermno").cast(pl.Int32, strict=False),
        alignment_anchor_expr.otherwise(pl.lit(None)).cast(pl.Date).alias("_alignment_anchor_date"),
        pl.lit(requested_alignment_policy).alias("alignment_policy_requested"),
        pl.lit(alignment_mode.value).alias("alignment_policy_effective"),
    )

    if alignment_mode == PhaseBAlignmentMode.FILING_DATE_EXACT_ONLY:
        exact_calendar = trading_calendar.select(
            pl.col("_calendar_date").alias("_alignment_anchor_date"),
            pl.lit(True).alias("_is_trading_date"),
        )
        aligned = (
            base.join(exact_calendar, on="_alignment_anchor_date", how="left")
            .with_columns(
                pl.when(pl.col("kypermno").is_not_null() & pl.col("_is_trading_date").fill_null(False))
                .then(pl.col("_alignment_anchor_date"))
                .otherwise(pl.lit(None, dtype=pl.Date))
                .alias("aligned_caldt")
            )
        )
    else:
        aligned = (
            base.sort("_alignment_anchor_date")
            .join_asof(
                trading_calendar,
                left_on="_alignment_anchor_date",
                right_on="_calendar_date",
                strategy="forward",
            )
            .rename({"_calendar_date": "aligned_caldt"})
            .with_columns(
                pl.when(pl.col("kypermno").is_not_null())
                .then(pl.col("aligned_caldt"))
                .otherwise(pl.lit(None, dtype=pl.Date))
                .alias("aligned_caldt")
            )
        )

    aligned = aligned.with_columns(
        pl.when(pl.col("aligned_caldt").is_not_null() & pl.col("filing_date").is_not_null())
        .then((pl.col("aligned_caldt") - pl.col("filing_date")).dt.total_days().cast(pl.Int32))
        .otherwise(pl.lit(None, dtype=pl.Int32))
        .alias("alignment_lag_days")
    )

    phase_a_ok = pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.OK.value)
    alignment_attempted = phase_a_ok & pl.col("kypermno").is_not_null()
    aligned_ok = alignment_attempted & pl.col("aligned_caldt").is_not_null()

    status = _update_data_status(
        pl.col("data_status"),
        conditional_flags=(
            (alignment_attempted, DataStatus.SEC_CCM_PHASE_B_ALIGNMENT_ATTEMPTED),
            (aligned_ok, DataStatus.SEC_CCM_PHASE_B_ALIGNED),
        ),
    ).alias("data_status")

    return aligned.with_columns(status).drop("_alignment_anchor_date", "_is_trading_date", strict=False)


def join_daily_phase_b(
    aligned_doc_lf: pl.LazyFrame,
    daily_lf: pl.LazyFrame,
    join_spec: SecCcmJoinSpec,
) -> pl.LazyFrame:
    """
    Join aligned docs to daily data under the configured Phase B daily-join mode.

    When daily joining is enabled, the result includes:
    ``daily_join_caldt``, ``daily_join_lag_days``, ``daily_lag_gate_rejected``,
    key-date coverage bounds, helper booleans, and updated ``data_status`` flags.
    ``daily_lag_gate_rejected`` is only applied as a usability gate for
    ``ASOF_FORWARD`` mode when ``daily_join_max_forward_lag_days`` is not ``None``.

    Args:
        aligned_doc_lf: Phase B aligned doc-grain rows.
        daily_lf: Daily input panel (CRSP or merged panel).
        join_spec: Phase B join configuration.

    Returns:
        pl.LazyFrame: Joined rows with daily fields and join diagnostics.

    Raises:
        ValueError: If required columns are missing, if daily join mode is unsupported,
            or if ``daily_join_max_forward_lag_days`` is negative.
        TypeError: If ``join_spec`` is an unsupported type.
    """
    join_spec_v2 = normalize_sec_ccm_join_spec(join_spec)
    _require_columns(
        aligned_doc_lf,
        ("doc_id", "kypermno", "aligned_caldt", "phase_a_reason_code", "data_status"),
        "Phase B aligned docs",
    )

    if not join_spec_v2.daily_join_enabled:
        return aligned_doc_lf.with_columns(
            pl.lit(None, dtype=pl.Date).alias("daily_join_caldt"),
            pl.lit(None, dtype=pl.Int32).alias("daily_join_lag_days"),
            pl.lit(False).alias("daily_lag_gate_rejected"),
            pl.lit(None, dtype=pl.Date).alias("key_min_caldt"),
            pl.lit(None, dtype=pl.Date).alias("key_max_caldt"),
            pl.lit(False).alias("_has_daily_row"),
            pl.lit(True).alias("_required_daily_features_ok"),
            pl.lit(False).alias("_daily_row_failed_required_features"),
            pl.lit(0, dtype=pl.Int32).alias("_missing_required_daily_feature_count"),
            pl.lit(False).alias("_has_usable_daily_row"),
        )

    daily = _normalize_daily_join_input(daily_lf, join_spec_v2)
    required_features = tuple(join_spec_v2.required_daily_non_null_features)
    if required_features:
        daily_schema = daily.collect_schema()
        missing_required = [col for col in required_features if col not in daily_schema]
        if missing_required:
            raise ValueError(f"Daily join normalized input missing required non-null feature columns: {missing_required}")
    coverage = daily.group_by("kypermno").agg(
        pl.col("daily_caldt").min().alias("key_min_caldt"),
        pl.col("daily_caldt").max().alias("key_max_caldt"),
    )

    left_base = (
        aligned_doc_lf
        .with_columns(pl.col("kypermno").cast(pl.Int32, strict=False))
        .join(coverage, on="kypermno", how="left")
    )
    if join_spec_v2.phase_b_daily_join_mode == PhaseBDailyJoinMode.ASOF_FORWARD:
        left_for_asof = left_base.sort("kypermno", "aligned_caldt")
        right_for_asof = daily.sort("kypermno", "daily_caldt")
        joined = (
            left_for_asof
            .join_asof(
                right_for_asof,
                left_on="aligned_caldt",
                right_on="daily_caldt",
                by="kypermno",
                strategy="forward",
                # We explicitly sort both sides by (group key, asof key) above.
                # Polars cannot validate grouped sortedness and otherwise emits a warning.
                check_sortedness=False,
            )
            .rename({"daily_caldt": "daily_join_caldt"})
        )
    elif join_spec_v2.phase_b_daily_join_mode == PhaseBDailyJoinMode.EXACT_ON_ALIGNED_DATE:
        right_for_exact = (
            daily
            .with_columns(
                pl.col("daily_caldt").alias("_join_caldt"),
                pl.col("daily_caldt").alias("daily_join_caldt"),
            )
            .drop("daily_caldt")
        )
        joined = (
            left_base
            .with_columns(pl.col("aligned_caldt").alias("_join_caldt"))
            .join(
                right_for_exact,
                on=["kypermno", "_join_caldt"],
                how="left",
            )
            .drop("_join_caldt")
        )
    else:
        raise ValueError(f"Unsupported phase_b_daily_join_mode: {join_spec_v2.phase_b_daily_join_mode.value}")

    has_daily_row = pl.col("daily_join_caldt").is_not_null()
    lag_days_expr = (
        pl.when(pl.col("daily_join_caldt").is_not_null() & pl.col("aligned_caldt").is_not_null())
        .then((pl.col("daily_join_caldt") - pl.col("aligned_caldt")).dt.total_days().cast(pl.Int32))
        .otherwise(pl.lit(None, dtype=pl.Int32))
    )
    if required_features:
        missing_required_feature_count_expr = (
            pl.when(has_daily_row)
            .then(pl.sum_horizontal([pl.col(col).is_null().cast(pl.Int32) for col in required_features]))
            .otherwise(pl.lit(0, dtype=pl.Int32))
            .cast(pl.Int32)
        )
        required_features_ok_expr = (
            pl.when(has_daily_row)
            .then(pl.all_horizontal([pl.col(col).is_not_null() for col in required_features]))
            .otherwise(pl.lit(True))
        )
    else:
        missing_required_feature_count_expr = pl.lit(0, dtype=pl.Int32)
        required_features_ok_expr = pl.lit(True)
    daily_row_failed_required_features_expr = has_daily_row & (missing_required_feature_count_expr > pl.lit(0))
    usable_expr = has_daily_row & required_features_ok_expr

    lag_gate_rejected_expr = pl.lit(False)
    max_forward_lag_days = join_spec_v2.daily_join_max_forward_lag_days
    if (
        join_spec_v2.phase_b_daily_join_mode == PhaseBDailyJoinMode.ASOF_FORWARD
        and max_forward_lag_days is not None
    ):
        if max_forward_lag_days < 0:
            raise ValueError(
                "daily_join_max_forward_lag_days must be non-negative when provided; "
                f"got {max_forward_lag_days}"
            )
        lag_gate_rejected_expr = has_daily_row & lag_days_expr.is_not_null() & (
            lag_days_expr > pl.lit(int(max_forward_lag_days))
        )
        usable_expr = usable_expr & lag_gate_rejected_expr.not_()

    daily_attempted = (
        (pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.OK.value))
        & pl.col("kypermno").is_not_null()
        & pl.col("aligned_caldt").is_not_null()
    )

    status = _update_data_status(
        pl.col("data_status"),
        conditional_flags=(
            (daily_attempted, DataStatus.SEC_CCM_PHASE_B_DAILY_JOIN_ATTEMPTED),
            (usable_expr, DataStatus.SEC_CCM_PHASE_B_DAILY_ROW_FOUND),
        ),
    ).alias("data_status")

    return joined.with_columns(
        has_daily_row.alias("_has_daily_row"),
        required_features_ok_expr.alias("_required_daily_features_ok"),
        daily_row_failed_required_features_expr.alias("_daily_row_failed_required_features"),
        missing_required_feature_count_expr.alias("_missing_required_daily_feature_count"),
        usable_expr.alias("_has_usable_daily_row"),
        lag_days_expr.alias("daily_join_lag_days"),
        lag_gate_rejected_expr.alias("daily_lag_gate_rejected"),
        status,
    )


def apply_phase_b_reason_codes(
    phase_a_doc_lf: pl.LazyFrame,
    phase_b_joined_lf: pl.LazyFrame,
    join_spec: SecCcmJoinSpec,
) -> pl.LazyFrame:
    """Apply Phase B reason codes while preserving non-OK Phase A outcomes.

    ``match_reason_code`` for rows that were not ``OK`` in Phase A is preserved
    from ``phase_a_reason_code``. For Phase A ``OK`` rows, Phase B emits
    ``OK``, ``OUT_OF_CCM_COVERAGE``, ``REQUIRED_DAILY_FEATURE_MISSING``,
    or ``NO_CCM_ROW_FOR_DATE``.

    Args:
        phase_a_doc_lf: Phase A output with at least ``doc_id`` and ``phase_a_reason_code``.
        phase_b_joined_lf: Phase B output with alignment/daily join diagnostics.
        join_spec: Phase B join configuration.

    Returns:
        pl.LazyFrame: Rows with ``phase_b_reason_code``, ``match_reason_code``,
        and updated ``data_status`` flags.

    Raises:
        ValueError: If required columns are missing in either input frame.
        TypeError: If ``join_spec`` is an unsupported type.
    """
    join_spec_v2 = normalize_sec_ccm_join_spec(join_spec)
    _require_columns(phase_a_doc_lf, ("doc_id", "phase_a_reason_code"), "Phase A docs")
    _require_columns(
        phase_b_joined_lf,
        ("doc_id", "phase_a_reason_code", "aligned_caldt", "data_status"),
        "Phase B joined docs",
    )

    phase_a_codes = phase_a_doc_lf.select("doc_id", "phase_a_reason_code").unique(subset=["doc_id"])
    out = phase_b_joined_lf.join(phase_a_codes, on="doc_id", how="left", suffix="_phase_a")
    if "phase_a_reason_code_phase_a" in out.collect_schema():
        out = out.with_columns(
            pl.coalesce([pl.col("phase_a_reason_code"), pl.col("phase_a_reason_code_phase_a")]).alias("phase_a_reason_code")
        ).drop("phase_a_reason_code_phase_a")

    schema = out.collect_schema()
    if "_has_daily_row" not in schema:
        out = out.with_columns(pl.lit(False).alias("_has_daily_row"))
    if "_has_usable_daily_row" not in schema:
        out = out.with_columns(pl.lit(False).alias("_has_usable_daily_row"))
    if "_daily_row_failed_required_features" not in schema:
        out = out.with_columns(pl.lit(False).alias("_daily_row_failed_required_features"))
    if "_missing_required_daily_feature_count" not in schema:
        out = out.with_columns(pl.lit(0, dtype=pl.Int32).alias("_missing_required_daily_feature_count"))
    if "daily_lag_gate_rejected" not in schema:
        out = out.with_columns(pl.lit(False).alias("daily_lag_gate_rejected"))
    if "key_min_caldt" not in schema:
        out = out.with_columns(pl.lit(None, dtype=pl.Date).alias("key_min_caldt"))
    if "key_max_caldt" not in schema:
        out = out.with_columns(pl.lit(None, dtype=pl.Date).alias("key_max_caldt"))

    phase_a_ok = pl.col("phase_a_reason_code") == pl.lit(MatchReasonCode.OK.value)
    base_coverage_miss = pl.col("aligned_caldt").is_null()
    if join_spec_v2.daily_join_enabled:
        coverage_miss = (
            base_coverage_miss
            | pl.col("key_min_caldt").is_null()
            | pl.col("key_max_caldt").is_null()
            | (pl.col("aligned_caldt") < pl.col("key_min_caldt"))
            | (pl.col("aligned_caldt") > pl.col("key_max_caldt"))
        )
        required_daily_feature_missing = (
            phase_a_ok
            & coverage_miss.not_()
            & pl.col("_has_daily_row")
            & pl.col("_daily_row_failed_required_features")
        )
        no_row_for_date = (
            phase_a_ok
            & coverage_miss.not_()
            & required_daily_feature_missing.not_()
            & pl.col("_has_usable_daily_row").not_()
        )
    else:
        coverage_miss = base_coverage_miss
        required_daily_feature_missing = pl.lit(False)
        no_row_for_date = pl.lit(False)

    phase_b_reason = (
        pl.when(phase_a_ok & coverage_miss)
        .then(pl.lit(MatchReasonCode.OUT_OF_CCM_COVERAGE.value))
        .when(required_daily_feature_missing)
        .then(pl.lit(MatchReasonCode.REQUIRED_DAILY_FEATURE_MISSING.value))
        .when(no_row_for_date)
        .then(pl.lit(MatchReasonCode.NO_CCM_ROW_FOR_DATE.value))
        .when(phase_a_ok)
        .then(pl.lit(MatchReasonCode.OK.value))
        .otherwise(pl.lit(None, dtype=pl.Utf8))
    )

    match_reason = (
        pl.when(phase_a_ok)
        .then(pl.coalesce([phase_b_reason, pl.lit(MatchReasonCode.OK.value)]))
        .otherwise(pl.col("phase_a_reason_code"))
    )

    status = _update_data_status(
        pl.col("data_status"),
        conditional_flags=(
            (
                phase_a_ok & (phase_b_reason == pl.lit(MatchReasonCode.OUT_OF_CCM_COVERAGE.value)),
                DataStatus.SEC_CCM_PHASE_B_OUT_OF_CCM_COVERAGE,
            ),
            (
                phase_a_ok & (phase_b_reason == pl.lit(MatchReasonCode.NO_CCM_ROW_FOR_DATE.value)),
                DataStatus.SEC_CCM_PHASE_B_NO_CCM_ROW_FOR_DATE,
            ),
            (
                phase_a_ok & (phase_b_reason == pl.lit(MatchReasonCode.REQUIRED_DAILY_FEATURE_MISSING.value)),
                DataStatus.SEC_CCM_PHASE_B_REQUIRED_DAILY_FEATURE_MISSING,
            ),
        ),
    ).alias("data_status")

    return out.with_columns(
        phase_b_reason.alias("phase_b_reason_code"),
        match_reason.alias("match_reason_code"),
        status,
    )


def build_match_status_doc(final_doc_lf: pl.LazyFrame) -> pl.LazyFrame:
    """Build the canonical doc-grain match-status table.

    Args:
        final_doc_lf: Final Phase B doc output.

    Returns:
        pl.LazyFrame: Canonical status table with fixed column order and
        ``match_flag`` derived from ``match_reason_code == 'OK'``.

    Raises:
        ValueError: If required columns are missing from ``final_doc_lf``.
    """
    required = ("doc_id", "cik_10", "filing_date", "phase_a_reason_code", "match_reason_code", "data_status")
    _require_columns(final_doc_lf, required, "final doc output")

    schema = final_doc_lf.collect_schema()
    out = final_doc_lf
    if "phase_b_reason_code" not in schema:
        out = out.with_columns(pl.lit(None, dtype=pl.Utf8).alias("phase_b_reason_code"))
    if "acceptance_datetime" not in schema:
        out = out.with_columns(pl.lit(None, dtype=pl.Datetime).alias("acceptance_datetime"))
    if "has_acceptance_datetime" not in schema:
        out = out.with_columns(pl.lit(False).alias("has_acceptance_datetime"))
    if "gvkey" not in schema:
        out = out.with_columns(pl.lit(None, dtype=pl.Utf8).alias("gvkey"))
    if "kypermno" not in schema:
        out = out.with_columns(pl.lit(None, dtype=pl.Int32).alias("kypermno"))
    if "aligned_caldt" not in schema:
        out = out.with_columns(pl.lit(None, dtype=pl.Date).alias("aligned_caldt"))
    if "alignment_lag_days" not in schema:
        out = out.with_columns(pl.lit(None, dtype=pl.Int32).alias("alignment_lag_days"))
    if "link_candidate_count" not in schema:
        out = out.with_columns(pl.lit(0, dtype=pl.Int32).alias("link_candidate_count"))
    if "top_rank_tie_count" not in schema:
        out = out.with_columns(pl.lit(0, dtype=pl.Int32).alias("top_rank_tie_count"))

    return out.with_columns(
        (pl.col("match_reason_code") == pl.lit(MatchReasonCode.OK.value)).alias("match_flag"),
    ).select(
        "doc_id",
        "cik_10",
        "filing_date",
        "gvkey",
        "kypermno",
        "phase_a_reason_code",
        "phase_b_reason_code",
        "match_reason_code",
        "match_flag",
        "aligned_caldt",
        "alignment_lag_days",
        "link_candidate_count",
        "top_rank_tie_count",
        "acceptance_datetime",
        "has_acceptance_datetime",
        "data_status",
    )


def build_unmatched_diagnostics_doc(
    final_doc_lf: pl.LazyFrame,
    link_universe_lf: pl.LazyFrame,
    daily_lf: pl.LazyFrame,
) -> pl.LazyFrame:
    """Build doc-grain diagnostics for unmatched filings.

    Args:
        final_doc_lf: Final Phase B doc output.
        link_universe_lf: CCM link universe used for enrichment diagnostics.
        daily_lf: Reserved for compatibility with earlier pipeline signatures;
            currently not used in this function.

    Returns:
        pl.LazyFrame: Unmatched filings enriched with CIK/link-coverage diagnostics.

    Raises:
        ValueError: If required columns are missing from input frames.
    """
    _require_columns(final_doc_lf, ("doc_id", "cik_10", "filing_date", "match_reason_code"), "final docs")
    link_universe = _normalize_link_universe(link_universe_lf, strict=True)
    cik_presence = link_universe.select(
        "cik_10",
        pl.lit(True).alias("diag_cik_in_link_universe"),
    ).unique(subset=["cik_10"])

    matched_counts = final_doc_lf.group_by("cik_10").agg(
        ((pl.col("match_reason_code") == pl.lit(MatchReasonCode.OK.value)).cast(pl.Int32)).sum().alias("diag_n_matched_for_cik")
    )

    date_valid_expr = (
        (pl.col("valid_start").is_null() | (pl.col("filing_date") >= pl.col("valid_start")))
        & (pl.col("valid_end").is_null() | (pl.col("filing_date") <= pl.col("valid_end")))
    )
    valid_candidate_stats = (
        final_doc_lf.select("doc_id", "cik_10", "filing_date")
        .unique(subset=["doc_id"])
        .join(
            link_universe.select(
                "cik_10",
                "kypermno",
                "has_window",
                "is_sparse_fallback",
                "valid_start",
                "valid_end",
            ),
            on="cik_10",
            how="left",
        )
        .with_columns(date_valid_expr.alias("_date_valid"))
        .filter(pl.col("_date_valid") & (pl.col("kypermno") > pl.lit(0)))
        .group_by("doc_id")
        .agg(
            pl.len().cast(pl.Int32).alias("diag_valid_candidate_count"),
            (
                pl.col("has_window") & pl.col("is_sparse_fallback").not_()
            ).cast(pl.Int32).sum().cast(pl.Int32).alias("diag_stage1_candidate_count"),
        )
    )

    form_col = None
    schema = final_doc_lf.collect_schema()
    for candidate in ("form_type", "document_type_filename", "SRCTYPE"):
        if candidate in schema:
            form_col = candidate
            break

    diag = (
        final_doc_lf
        .filter(pl.col("match_reason_code") != pl.lit(MatchReasonCode.OK.value))
        .join(cik_presence, on="cik_10", how="left")
        .join(matched_counts, on="cik_10", how="left")
        .join(valid_candidate_stats, on="doc_id", how="left")
        .with_columns(
            pl.col("diag_cik_in_link_universe").fill_null(False),
            pl.col("diag_n_matched_for_cik").fill_null(0).cast(pl.Int32),
            pl.col("diag_valid_candidate_count").fill_null(0).cast(pl.Int32),
            pl.col("diag_stage1_candidate_count").fill_null(0).cast(pl.Int32),
            (pl.col("diag_n_matched_for_cik") > 0).alias("has_other_filings_matched_for_cik"),
            (pl.col("diag_valid_candidate_count") > 0).alias("diag_has_date_valid_candidate"),
        )
    )

    diag_schema = diag.collect_schema()
    if "aligned_caldt" in diag_schema and "key_min_caldt" in diag_schema and "key_max_caldt" in diag_schema:
        diag = diag.with_columns(
            (
                pl.col("aligned_caldt").is_not_null()
                & pl.col("key_min_caldt").is_not_null()
                & (pl.col("aligned_caldt") < pl.col("key_min_caldt"))
            ).alias("diag_aligned_before_key_coverage"),
            (
                pl.col("aligned_caldt").is_not_null()
                & pl.col("key_max_caldt").is_not_null()
                & (pl.col("aligned_caldt") > pl.col("key_max_caldt"))
            ).alias("diag_aligned_after_key_coverage"),
        )
    else:
        diag = diag.with_columns(
            pl.lit(False).alias("diag_aligned_before_key_coverage"),
            pl.lit(False).alias("diag_aligned_after_key_coverage"),
        )
    diag_schema = diag.collect_schema()
    if "_has_daily_row" in diag_schema:
        diag = diag.with_columns(pl.col("_has_daily_row").fill_null(False).alias("diag_has_daily_row"))
    else:
        diag = diag.with_columns(pl.lit(False).alias("diag_has_daily_row"))
    diag_schema = diag.collect_schema()
    if "_daily_row_failed_required_features" in diag_schema:
        diag = diag.with_columns(
            pl.col("_daily_row_failed_required_features").fill_null(False).alias("diag_daily_row_failed_required_features")
        )
    else:
        diag = diag.with_columns(pl.lit(False).alias("diag_daily_row_failed_required_features"))
    diag_schema = diag.collect_schema()
    if "_missing_required_daily_feature_count" in diag_schema:
        diag = diag.with_columns(
            pl.col("_missing_required_daily_feature_count").fill_null(0).cast(pl.Int32).alias(
                "diag_missing_required_daily_feature_count"
            )
        )
    else:
        diag = diag.with_columns(pl.lit(0, dtype=pl.Int32).alias("diag_missing_required_daily_feature_count"))

    if "acceptance_datetime" not in diag_schema:
        diag = diag.with_columns(pl.lit(None, dtype=pl.Datetime).alias("acceptance_datetime"))
    if "has_acceptance_datetime" not in diag_schema:
        diag = diag.with_columns(pl.lit(False).alias("has_acceptance_datetime"))

    selected = [
        "doc_id",
        "cik_10",
        "filing_date",
    ]
    if form_col is not None:
        selected.append(form_col)
    selected.extend(
        [
            "match_reason_code",
            "phase_a_reason_code",
            "phase_b_reason_code",
            "gvkey",
            "kypermno",
            "link_candidate_count",
            "top_rank_tie_count",
            "diag_cik_in_link_universe",
            "has_other_filings_matched_for_cik",
            "diag_n_matched_for_cik",
            "diag_aligned_before_key_coverage",
            "diag_aligned_after_key_coverage",
            "diag_valid_candidate_count",
            "diag_stage1_candidate_count",
            "diag_has_date_valid_candidate",
            "diag_has_daily_row",
            "diag_daily_row_failed_required_features",
            "diag_missing_required_daily_feature_count",
            "aligned_caldt",
            "alignment_lag_days",
            "acceptance_datetime",
            "has_acceptance_datetime",
        ]
    )
    present = [col for col in selected if col in diag.collect_schema()]
    return diag.select(present)
